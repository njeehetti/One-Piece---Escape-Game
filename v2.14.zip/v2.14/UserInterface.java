import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.BoxLayout;

import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Image;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

import java.net.URL;
import java.util.Set; // utile pour l'utilisation de la hashmap des sorties pour la sortie dynamiques des boutons de deplacement.
//import java.awt.image.*;
import java.util.HashMap; // utile pour afficher les items du Player ou de la Room
import java.util.List;
import java.util.Arrays;




/**
 * This class implements a simple graphical user interface with a 
 * text entry area, a text output area and an optional image.
 * 
 * @author Michael Kolling &amp; Njee Hettiarachchi
 * @version 1.0 (Jan 2003) DB edited (2023)
 * @version 2.0 (Jan 2024)
 */
public class UserInterface implements ActionListener
{
    /**
     * Moteur de jeu.
     */
    private GameEngine aEngine;
    
    /**
     * Fenetre principale de l'application.
     */
    private JFrame aMyFrame;
    
    /**
     * Champ de saisie du texte pour les commandes.
     */
    private JTextField aEntryField;
    
    /**
     * Zone de texte pour afficher les logs.
     */
    private JTextArea aLog;
    
    /**
     * Élément d'image.
     */
    private JLabel aImage;
    
    /**
     * Bouton utilisé dans l'interface.
     */
    private JButton aButton;
    
    /**
     * Panel pour le menu des boutons.
     */
    private JPanel aPanelMenuBoutons = new JPanel();
    
    /**
     * Panel pour les directions.
     */
    private JPanel aPanelDir = new JPanel();
    
    /**
     * Checker indiquant l'affichage du bouton "start" au lancement du jeu.
     */
    private boolean aChecker = false; // Sera utile pour afficher le bouton start au lancement du jeu
    
    /**
     * Checker pour l'affichage de la liste d'item.
     */
    private boolean aList = false; // Onglet avec commandes d'affichage de liste d'items (ex : take)
    
    
    /**
     * Checker pour l'affichage du menu joueur.
     */
    private boolean aPlayerMenu = false; // Onglets pour commande specifique du joueur (ex: look)
    
    
    /**
     * Checker pour l'affichage de la liste d'item.
     */
    private boolean aFinalMenu = false; // Onglet avec commandes pour le dernier choix du jeu (ex : flee et launch)
    
    
    /**
     * Dernier bouton clique
     */
    private JButton aDernierClique =null; // Utile pour faire une association -> boutons "take" et "item" qui donnera "take item"
    
    /**
     * Avant dernier bouton clique 
     */
    private JButton aAvantDernierClique=null; // va avec le bouton aDernierClique, utile dans le action performed pour garder en memoire l'avant dernier bouton
    
    
    
    /**
     * Type d'action en cours.
     */
    private String aActionType = "go"; // Permettra de différencier les differentes actions du actionListener
    
    /**
     * Temps de jeu reste
     */
    private JLabel aTimer; // Pour le decompte du temps qu'il reste a jouer
    
    /**
     * Avancement dans les quetes du jeu
     */
    private int aGameProgess = 0; // Pour le decompte du temps qu'il reste a jouer
    
    /**
     * Construit une interface utilisateur. En tant que paramètre,
     * un moteur de jeu (un objet traitant et executant les commandes du jeu) 
     * est necessaire."
     * 
     * @param pGameEngine  L'object GameEngine implementant la logique de jeu.
     */
    public UserInterface( final GameEngine pGameEngine )
    {
        this.aEngine = pGameEngine;
        this.createGUI();
    } // UserInterface(.)
    
    /**
     * Retourne l'objet GameEngine
     * @return l'attribut aEngine
     */
    public GameEngine getEngine()
    {
        return this.aEngine;
    }
    
    /**
     * Affiche une sortie au format texte dans la zone de texte
     * @param pText Le texte a afficher
     */
    public void print( final String pText )
    {
        this.aLog.append( pText );
        this.aLog.setCaretPosition( this.aLog.getDocument().getLength() );
    } // print(.)
    
    /**
     * Affichez du texte dans la zone de texte, suivi d'un saut de ligne
     * @param pText le contenu a afficher dans la zone de texte
     */
    public void println( final String pText )
    {
        this.print( pText + "\n" );
    } // println(.)

    /**
     * Affichage du temps restant a jouer
     * @param pTime le temps restant
     */
    public void updateTimer(final int pTime) {
        if (pTime > 60){
            this.aTimer.setText("Il vous reste: " + pTime/60 + "m "+ pTime%60 +"s"); 
        }
        else
            this.aTimer.setText("Il vous reste: " + pTime+"s"); 
    }
    
    /**
     * Met un terme au decompte du temps
     */
    public void stopTimer() {
        this.aTimer.setText("GAME OVER");
        //this.enable(false);
    }
    
    /**
     * Met un terme au decompte du temps
     */
    public void stopTimerWon() {
        this.aTimer.setText("MISSION ACCOMPLISHED"); 
        //this.enable(false);
    }
    
    /**
     * Afficher une image dans la zone de texte
     * @param pImageName Le nom de l'image a afficher
     */
    public void showImage( final String pImageName )
    {
        String vImagePath = "Images/" + pImageName; // to change the directory
        URL vImageURL = this.getClass().getClassLoader().getResource( vImagePath );
        if ( vImageURL == null )
            System.out.println( "Image non trouvee : " + vImagePath );
        else {
            ImageIcon vIcon = new ImageIcon( vImageURL );
            Image vResizedImg = vIcon.getImage().getScaledInstance(600, 398, Image.SCALE_SMOOTH); //Issu de ChatGPT pour fixer la taille de l'image sans réduire la résolution 
            ImageIcon vResizedIcon = new ImageIcon(vResizedImg); // deuxième partie de la méthode resized
            
            
            this.aImage.setIcon( vResizedIcon );
            this.aMyFrame.pack();
        }
    } // showImage(.)
    
    /**
     * Determiner si on veut activer ou desactiver la saisie de texte
     * @param pOnOff le checker qui va determiner si on active ou desactive la saisie de texte
     */
    public void enable( final boolean pOnOff )
    {
        this.aEntryField.setEditable( pOnOff ); // enable/disable
        if ( pOnOff ) { // enable
            this.aEntryField.getCaret().setBlinkRate( 500 ); // cursor blink
            this.aEntryField.addActionListener( this ); // reacts to entry
        }
        else { // disable
            this.aEntryField.getCaret().setBlinkRate( 0 ); // cursor won't blink
            this.aEntryField.removeActionListener( this ); // won't react to entry
        }
    } // enable(.)

    //Pour simuler une page d'accueil pour le jeu et gérer son activation desactivation
    /**
     * Verifie si le jeu a ete demarre (State Checker)
     * @return true si le jeu a demarre, sinon false.
     */
    public boolean hasStarted()
    {
        return this.aChecker;
    }
    
    /**
     * Active ou desactive le demarrage du jeu.
     */
    public void getStarted()
    {
        this.aChecker = !this.aChecker;
    }
    
    
    //Creation d'un panel Player Actions regroupant des commandes propres au joueur (ex: Take/Drop)
    /**
     * Verifie si le menu de boutons est ouvert (State checker)
     * @return true s'il est ouvert, sinon false.
     */
    public boolean isPlayerMenuOpened()
    {
        return this.aPlayerMenu;
    }
    
    /**
     * Active ou desactive le panel de menu player.
     */
    public void changePlayerMenuState()
    {
        this.aPlayerMenu = !this.aPlayerMenu;
    }
    
    //Creation d'un panel Player Actions regroupant des commandes propres au joueur (ex: Take/Drop)
    /**
     * Verifie si le menu final est ouvert (State checker)
     * @return true s'il est ouvert, sinon false.
     */
    public boolean isFinalMenuOpened()
    {
        return this.aFinalMenu;
    }
    
    /**
     * Active ou desactive le panel final.
     */
    public void changeFinalMenuState()
    {
        this.aFinalMenu = !this.aFinalMenu;
    }
    
    
    /**
     * Verifie si le menu des elements est ouvert (State checker)
     * @return true s'il est ouvert, sinon false.
     */
    public boolean isListOpened()
    {
        return this.aList;
    }
    
    /**
     * Active ou desactive le panel de menu player.
     */
    public void changeListState()
    {
        this.aList = !this.aList;
    }
    
    
    /**
     * Set up graphical user interface.
     */
    private void createGUI()
    {
        this.aMyFrame = new JFrame( "Controls" );
        this.aMyFrame.setSize(600, 398);
        this.aMyFrame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Définit la JFrame en plein écran
        this.aMyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Ferme 
        
        this.aEntryField = new JTextField( 34 );
        //this.enable(false);
        
        
        //Grille des boutons de base
        this.aPanelMenuBoutons.setLayout(new GridLayout(4,1,5,5));
        
        //Grille des boutons de Direction
        this.aPanelDir.setLayout(new BoxLayout(this.aPanelDir, BoxLayout.PAGE_AXIS));
        
        //Placement des boutons dans les Panels respectifs
        UpdateBoutons();
        
        this.aLog = new JTextArea();
        this.aLog.setEditable( false );
        this.aLog.setLineWrap(true); // pour revenir a la ligne
        this.aLog.setWrapStyleWord(true); // pour ne pas couper des mots en revenant a la ligne
        
        JScrollPane vListScroller = new JScrollPane( this.aLog );
        vListScroller.setPreferredSize( new Dimension(200, 350) ); // 350 pour allonger la zone de texte
        vListScroller.setMinimumSize( new Dimension(100,100) );

        this.aImage = new JLabel(); // pour l'image
        this.aTimer = new JLabel(); // pour le decompte 

        
        JPanel vPanelBoutons = new JPanel();
        vPanelBoutons.setLayout( new BoxLayout(vPanelBoutons, BoxLayout.PAGE_AXIS));
        vPanelBoutons.add(this.aPanelMenuBoutons);
        vPanelBoutons.add(this.aPanelDir);
        
        JPanel vPanelCentral = new JPanel();
        vPanelCentral.setLayout( new BoxLayout(vPanelCentral, BoxLayout.PAGE_AXIS));
        vPanelCentral.add(aTimer);
        vPanelCentral.add(vListScroller);
        
        JPanel vPanel = new JPanel();
        vPanel.setLayout( new BorderLayout() ); // ==> only five places
        vPanel.add( this.aImage, BorderLayout.NORTH );
        //vPanel.add( vListScroller, BorderLayout.CENTER );
        vPanel.add( this.aEntryField, BorderLayout.SOUTH );
        vPanel.add( vPanelBoutons, BorderLayout.WEST );
        //vPanel.add(this.aTimer,BorderLayout.EAST);
        vPanel.add( vPanelCentral, BorderLayout.CENTER );
        
        this.aMyFrame.getContentPane().add( vPanel, BorderLayout.CENTER );

        // add some event listeners to the entry field
        this.aEntryField.addActionListener( this );

        // to end program when window is closed
        this.aMyFrame.addWindowListener(
            new WindowAdapter() { // anonymous class
                @Override public void windowClosing(final WindowEvent pE)
                {
                    System.exit(0);
                }
        } );

        this.aMyFrame.pack();
        this.aMyFrame.setVisible( true );
        this.aEntryField.requestFocus();
    } // createGUI()

    
    /**
     * Modifie intelligent et contextuellement la disposition des boutons, en prenant en compte les state checkers 
     */
    public void UpdateBoutons()
    {
        this.aPanelDir.removeAll();
        this.aPanelMenuBoutons.removeAll(); 
        
        JButton vBStart = new JButton ("Start");
        vBStart.setActionCommand("start");
        vBStart.addActionListener(this);
        
        JButton vBHelp = new JButton ("Help");
        vBHelp.setActionCommand("help");
        vBHelp.addActionListener(this);
        
        JButton vBQuit = new JButton ("Quitter");
        vBQuit.setActionCommand("quit");
        vBQuit.addActionListener(this);
        
        JButton vBLook = new JButton ("Look around");
        vBLook.setActionCommand("look");
        vBLook.addActionListener(this);
        
        JButton vBTake = new JButton ("Take");
        vBTake.setActionCommand("itemlist");
        vBTake.addActionListener(this);
        
        JButton vBUnlock = new JButton ("Try To Unlock");
        vBUnlock.setActionCommand("unlock");
        vBUnlock.addActionListener(this);
        
        JButton vBDrop = new JButton ("Drop");
        vBDrop.setActionCommand("itemlist");
        vBDrop.addActionListener(this);
        
        JButton vBUse = new JButton ("Use");
        vBUse.setActionCommand("itemlist");
        vBUse.addActionListener(this);
        
        JButton vBBack = new JButton ("Back");
        vBBack.setActionCommand("back");
        vBBack.addActionListener(this);

        
        JButton vBTalk = new JButton ("Talk");
        vBTalk.setActionCommand("itemlist");
        vBTalk.addActionListener(this);
        
        JButton vBCharge = new JButton ("Charge");
        vBCharge.setActionCommand("itemlist");
        vBCharge.addActionListener(this);
        
        JButton vBInventory = new JButton ("Inventory");
        vBInventory.setActionCommand("inventory");
        vBInventory.addActionListener(this);
        
        JButton vBPlayerMenu = new JButton ("Player Actions");
        vBPlayerMenu.setActionCommand("playerActions");
        vBPlayerMenu.addActionListener(this);
        
        JButton vBBackPlayerActions1 = new JButton ("Return");
        vBBackPlayerActions1.setActionCommand("returnPlayerActions1");
        vBBackPlayerActions1.addActionListener(this);
        
        JButton vBBackPlayerActions2 = new JButton ("Return");
        vBBackPlayerActions2.setActionCommand("returnPlayerActions2");
        vBBackPlayerActions2.addActionListener(this);
        
        JButton vBLaunch = new JButton ("Launch COUP DE BURST!");
        vBLaunch.setActionCommand("launch");
        vBLaunch.addActionListener(this);
        
        JButton vBFlee = new JButton ("Give UP :(");
        vBFlee.setActionCommand("flee");
        vBFlee.addActionListener(this);
        
        JButton vBGive = new JButton ("Give to Zoro");
        vBGive.setActionCommand("give");
        vBGive.addActionListener(this);
        
        
        if (!hasStarted())
        {
            this.aPanelMenuBoutons.add(vBStart);
            this.aPanelMenuBoutons.add(vBHelp);
            this.aPanelMenuBoutons.add(vBQuit);
        }
        else{
            if (isPlayerMenuOpened())
            {
                this.aPanelMenuBoutons.removeAll();
                
                this.aPanelMenuBoutons.add(vBLook);
                this.aPanelMenuBoutons.add(vBInventory);
                this.aPanelMenuBoutons.add(vBTalk);
                if (!this.getEngine().getPlayer().getRoom().getLoot().getItemList().isEmpty()){
                    if (this.getEngine().getPlayer().getRoom().getLoot().isOpenable() == false){
                        this.aPanelMenuBoutons.add(vBUnlock);
                    }
                    else
                        this.aPanelMenuBoutons.add(vBTake);
                }
                
                if (!this.getEngine().getPlayer().getInventory().getItemList().isEmpty()){
                    this.aPanelMenuBoutons.add(vBDrop);
                    this.aPanelMenuBoutons.add(vBUse);
                }
                for (Item vItem : this.getEngine().getPlayer().getInventory().getItemList().values()) {
                    if (vItem instanceof Beamer) {
                        this.aPanelMenuBoutons.add(vBCharge);
                    }
                }
                
                if (this.getEngine().playerHas("Haltere") && this.getEngine().roomIs("Training"))
                    this.aPanelMenuBoutons.add(vBGive);
                this.aPanelMenuBoutons.add(vBBackPlayerActions1);
            }
            
            else if (isListOpened())
            {
                this.aActionType = aDernierClique.getText().toLowerCase();
                
                this.aPanelMenuBoutons.removeAll();
                
                ItemList vItemsToBeShown = new ItemList();
                CharacterList vCharactersToBeShown = new CharacterList();
                if (aActionType.equals("take"))
                {
                    vCharactersToBeShown = null;
                    vItemsToBeShown = this.aEngine.getPlayer().getRoom().getLoot();
                }
                else if (aActionType.equals("talk"))
                {
                    vItemsToBeShown = null;
                    vCharactersToBeShown = this.aEngine.getPlayer().getRoom().getPersonnages();
                }
                else 
                    vItemsToBeShown = this.aEngine.getPlayer().getInventory(); // Pour drop use et charge
                // Nous venons de recuperer l'objet ItemList comprenant les items a afficher
                
                if (vItemsToBeShown!=null && !aActionType.equals("charge"))
                {
                    Set<String> vItemKeys = vItemsToBeShown.getItemList().keySet();
                    for (String vItems : vItemKeys) {
                        /**JPanel vPanelAdded = new JPanel();
                        vPanelAdded.setLayout(new BoxLayout(vPanelAdded, BoxLayout.LINE_AXIS));*/
                        JButton vBItem = new JButton (vItems);
                        vBItem.setActionCommand(vItems);
                        vBItem.addActionListener(this);
                        this.aPanelMenuBoutons.add(vBItem);
                    }
                }
                
                else if (vItemsToBeShown!=null && aActionType.equals("charge"))
                {
                    Set<String> vItemKeys = vItemsToBeShown.getItemList().keySet();
                    for (String vItems : vItemKeys) {
                        /**JPanel vPanelAdded = new JPanel();
                        vPanelAdded.setLayout(new BoxLayout(vPanelAdded, BoxLayout.LINE_AXIS));*/
                        Item vItem = this.aEngine.getPlayer().getInventory().getItemFromList(vItems); // verifie si l'item est bien un Beamer
                        if (vItem instanceof Beamer){
                            JButton vBItem = new JButton (vItems);
                            vBItem.setActionCommand(vItems);
                            vBItem.addActionListener(this);
                            this.aPanelMenuBoutons.add(vBItem);
                        }
                    }
                }
                
                else if (vCharactersToBeShown!=null)
                {
                    Set<String> vCharacterKeys = vCharactersToBeShown.getCharacterList().keySet();
                    for (String vPersos : vCharacterKeys) {
                        /**JPanel vPanelAdded = new JPanel();
                        vPanelAdded.setLayout(new BoxLayout(vPanelAdded, BoxLayout.LINE_AXIS));*/
                        JButton vBPerso = new JButton (vPersos);
                        vBPerso.setActionCommand(vPersos);
                        vBPerso.addActionListener(this);
                        this.aPanelMenuBoutons.add(vBPerso);
                    }
                }
                this.aPanelMenuBoutons.add(vBBackPlayerActions2);
            }
            
            else if (isFinalMenuOpened())
                {
                    this.aPanelMenuBoutons.removeAll();
                    if (aEngine.getIsEngineSet())
                        this.aPanelMenuBoutons.add(vBLaunch);
                    this.aPanelMenuBoutons.add(vBFlee);
                }
            else 
            {
                this.aActionType = "go";
                
                this.aPanelMenuBoutons.removeAll();
                this.aPanelMenuBoutons.add(vBPlayerMenu);
                this.aPanelMenuBoutons.add(vBHelp);
                this.aPanelMenuBoutons.add(vBBack);
                this.aPanelMenuBoutons.add(vBQuit);
                
                Set<String> vKeys = this.aEngine.getRoom().getExits().keySet();
                for (String vExit : vKeys) {
                    JPanel vPanelAdded = new JPanel();
                    vPanelAdded.setLayout(new BoxLayout(vPanelAdded, BoxLayout.LINE_AXIS));
                    JButton vBDir = new JButton (vExit);
                    vBDir.setActionCommand(vExit);
                    vBDir.addActionListener(this);
                    vPanelAdded.add(vBDir);
                    this.aPanelDir.add(vPanelAdded);
                }
            }
        }
        
        this.aPanelMenuBoutons.revalidate(); // trouvé sur Stack overflow
        this.aPanelMenuBoutons.repaint(); // Stack overflow
        
        this.aPanelDir.revalidate();
        this.aPanelDir.repaint();
    }
    
    /**
     * Interface action listener pour la zone de texte
     * @param pE l'action qui va etre interpretee
     */
    @Override public void actionPerformed( final ActionEvent pE) 
    {
        //this.aLog.setText(""); // Pour "clear" la zone de texte
        if (pE.getSource() instanceof JTextField){
            this.processCommand();
            if (pE.getActionCommand().contains("go"))
                UpdateBoutons();
            return;
        }
        else if (pE.getSource() instanceof JButton){ // pE.getSource() instanceof JButton
            List<String> vPlayerActionList = Arrays.asList("take", "drop", "use","talk","charge","itemlist","returnPlayerActions1"); // autoristation des associations de boutons pour ces commandes specifiques, qui evite de les reutiliser consecutivement Ex : talk talk
            List<String> vAvoidActionList = Arrays.asList("inventory", "look", "returnPlayerActions2"); 
            String vToBeProcessed = pE.getActionCommand();
            this.aAvantDernierClique = this.aDernierClique;
            this.aDernierClique = (JButton) pE.getSource(); //car sinon on obtient juste un Objet en retour et non plus le Bouton
            
            if (this.aEngine.getRoom().getExits().containsKey(vToBeProcessed))
            {
                this.aEngine.interpretCommand(aActionType + " " + vToBeProcessed); // go Room
            }
            
            else if (vPlayerActionList.contains(this.aActionType)) // execution des association de bouton ex : "take" + "item" = "take item"
            {
                String vInterpret = aDernierClique.getActionCommand(); // getActionCommand() trouve dans la javadoc de AbstractButton
                if ( vAvoidActionList.contains(vInterpret)) // Pour eviter des incoherences du type "take look" -> executera ici seulement look
                {
                    this.aEngine.interpretCommand(vInterpret);  
                }
                else if (vPlayerActionList.contains(vInterpret))
                {
                    this.aEngine.interpretCommand(vInterpret);  
                }
                
                
                else
                {
                    this.aEngine.interpretCommand(aActionType + " " + vInterpret); //commande de direction "go direction"
                    aActionType = "go";
                }
            }
            else{
                if (aDernierClique.getActionCommand().equals("help") && aAvantDernierClique.getActionCommand().equals("quit"))
                    this.aEngine.printWelcome();
                else
                    this.aEngine.interpretCommand(vToBeProcessed);  // commande basique comme "back" ou "help"
            }
        }
        UpdateBoutons();
    } // actionPerformed(.)

    /**
     * A command has been entered in the entry field.  
     * Read the command and do whatever is necessary to process it.
     */
    private void processCommand()
    {
        String vInput = this.aEntryField.getText();
        this.aEntryField.setText( "" );
        this.aEngine.interpretCommand( vInput );
    } // processCommand()
} // UserInterface 
