
import java.util.Set;
/**
 * Classe Character - un lieu du jeu d'aventure Zuul.
 *
 * @author Njee Hettiarachchi
 */
public class Character
{
    /**
     * Titre de l'Item.
     */
    private String aName;
    
    /**
     * Description de l'Item.
     */
    private String aDescription;
    
    /**
     * Dialogue du personnage.
     */
    private String aMessage;
    
    /**
     * Constructeur par defaut de la classe Character.
     * Initialise un nouvel objet Character avec un titre, une description et un message.
     * @param pName Le nom du Character.
     * @param pDescription La description du Character.
     */
    public Character(final String pName,final String pDescription)
    {
        this.aDescription = pDescription;
        this.aName = pName;
        this.aMessage = "Je n'ai rien a dire";
    }

    /**
     * Accesseur du nom de l'Item
     * @return l'attribut du nom de l'Item
     */
    public String getName()
    {
        return this.aName;
    } 

    /**
     * Accesseur de la description du character
     * @return l'attribut de description de la Character
     */
    public String getDescription()
    {
        return this.aDescription;
    } 
    
    
    
    /**
     * Accesseur du message du character.
     * @return le message de dialogue.
     */
    public String getMessage()
    {
        return this.aMessage;
    } 
    
    /**
     * Modifie le message du personnage
     * @param pMessage le nouveau message de dialogue.
     */
    public void setMessage(final String pMessage)
    {
        this.aMessage = pMessage;
    } 

    /**
     * Methode de texte, qui retourn la description de l'Item
     * @return la description associee à l'Item actuelle.
     */
    public String getCharacterString()
    {
        return this.aName + " : " + this.aDescription +"\n";
    } //get desc
    
    
}

