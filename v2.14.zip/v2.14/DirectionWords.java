
/**
 * This class is part of the "Treasure Cruise" application. 
 * "Treasure Cruise" is a very simple, text based adventure game.  
 * 
 * This class holds an enumeration table of all command words known to the game.
 * It is used to recognise commands as they are typed in.
 *
 * @author  Njee
 * @version 2023.10.13
 */

public class DirectionWords
{
    /**
     * Tableau contenant les commandes valides disponibles pour les directions.
     */
    private final String[] aValidDirections;
    
    /**
     * Constructeur par défaut - Initialise les différentes commandes.
     */
    public DirectionWords()
    {
        this.aValidDirections = new String[10];
        this.aValidDirections[0] = "north";
        this.aValidDirections[1] = "south";
        this.aValidDirections[2] = "east";
        this.aValidDirections[3] = "west";
        this.aValidDirections[4] = "up";
        this.aValidDirections[5] = "down";
        this.aValidDirections[6] = "escaliers";
        this.aValidDirections[7] = "escaliers_avant";
        this.aValidDirections[8] = "escaliers_arriere";
        this.aValidDirections[9] = "mirror";
    } // CommandWords()
    
    /**
     * Vérifie si la String donnée correspond à une direction valide.
     * @param pString la chaîne à vérifier
     * @return true si la chaîne correspond à une direction valide, false sinon.
     */
    public boolean isDirection( final String pString )
    {
        for ( int vI=0; vI<this.aValidDirections.length; vI++ ) {
            if ( this.aValidDirections[vI].equals( pString ) )
                return true;
        } // for
        // if we get here, the string was not found in the commands :
        return false;
    } // isCommand()
} // CommandWords