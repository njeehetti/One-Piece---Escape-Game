
/**
 * Classe Command - une commande du jeu d'aventure Zuul.
 *
 * @author Njee
 */

public class Command
{
    /**
     * Mot de commande principal pour une action.
     */
    private String aCommandWord;
    /**
     * Second mot de commande secondaire
     */
    private String aSecondWord;
    
    /**
     * Constructeur naturel de la classe Command.
     * Initialise une nouvelle instance de Command avec un mot de commande principal et un second mot optionnel.
     * @param pCommandWord le mot de commande principal
     * @param pSecondWord le second mot optionnel
     */
    public Command(final String pCommandWord, final String pSecondWord)
    {
        this.aCommandWord = pCommandWord;
        this.aSecondWord = pSecondWord;
    }
    
    /**
     * Accesseur
     * @return l'attribut associe à la Command utilisateur
     */
    public String getCommandWord()
    {
        return this.aCommandWord;
    }
    
    /**
     * Accesseur
     * @return l'attribut secondaire pour des Commandes specifiques
     */
    public String getSecondWord()
    {
        return this.aSecondWord;
    }
    
    /**
     * Methode de verification
     * @return une indication sur l'existence ou non d'une Command composee
     */
    public boolean hasSecondWord()
    {
        return (this.aSecondWord != null);
    }
    
    /**
     * Methode de verification
     * @return une indication sur l'existence ou non d'une Command principale valide
     */
    public boolean isUnknown()
    {
        return (this.aCommandWord == null);
    }
    
    
} // Command
