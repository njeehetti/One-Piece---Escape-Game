import java.util.HashMap;
import java.util.Set;
import java.util.Collection;

/**
 * Classe Room - un lieu du jeu d'aventure Zuul.
 *
 * @author Njee
 */
public class Room
{
    /**
     * Titre de la piece.
     */
    private String aTitle;
    
    /**
     * Description de la piece.
     */
    private String aDescription;
    
    /**
     * HashMap des sorties de la piece.
     */
    private HashMap<String, Room> aExits;
    
    /**
     * HashMap des sorties de la piece.
     */
    //private HashMap<String, Door> aDoors;
    /**
     * Nom de l'image associee a la piece.
     */
    private String aImageName;
    
    /**
     * Liste d'Items disponibles dans la piece.
     */
    private ItemList aLoot;

    /**
     * Liste des Personages presents dans la piece.
     */
    private CharacterList aPersoList;
    
    
    /**
     * Constructeur naturel de la classe Room.
     * Initialise une nouvelle instance de Room avec un titre et une description.
     * @param pTitle le titre de la Room
     * @param pDescription la description de la Room
     */
    public Room(final String pTitle,final String pDescription)
    {
        this.aDescription = pDescription;
        this.aTitle = pTitle;
        this.aExits = new HashMap<String,Room>();
        this.aLoot = new ItemList();
        this.aPersoList = new CharacterList();
        this.aImageName = new String();
    }

    
    /**
     * Accesseur
     * @return l'attribut de description de la Room
     */
    public String getDescription()
    {
        return this.aDescription;
    } //get desc
    
    /**
     * Accesseur de la hashmap de sorties de la Room
     * @return la hashmap de sorties de la Room
     */
    public HashMap<String,Room> getExits() {
        return aExits;
    }
    
    /**
     * Verifie si la Room passee en parametre est bien une sortie dispo
     * @param pRoom la Room a verifier
     * @return true si c'est le cas, non le cas echeant
     */
    public boolean isExit(final Room pRoom) {
        Collection<Room> vAllRooms = aExits.values(); // recuperation dans une collection de tous les Room de sortie de la Room
        return vAllRooms.contains(pRoom); // contains a ete trouvee dans la javadoc de Collection
    }
    
    /**
     * Methode de texte
     * @return la description associee à la Room actuelle.
     */
    public String getLongDescription()
    {
        String vSortie = "Vous etes "+ this.aDescription + "\n" + this.getExitString();
        if (this.aLoot.getItemList().isEmpty()){
            vSortie += "\nCette piece ne possede pas de loot\n";
        }
        else{
            vSortie += "\n\nLes Items suivants sont presents dans la piece ou vous vous trouvez :\n";
            vSortie += aLoot.getInventoryList();
        }
        return vSortie;
    } //get desc
    
    /**
     * Methode de texte
     * @return la description associee aux items de la Room actuelle.
     */
    public String getItemDescription()
    {
        String vSortie = new String();
        if (this.aLoot.getItemList().isEmpty()){
            vSortie += "\nCette piece ne possede pas de loot\n";
        }
        else{
            vSortie += "\n\nItems presents dans la piece :\n";
            vSortie += aLoot.getInventoryList();
        }
        return vSortie;
    } //get desc
    
    /**
     * Methode de texte
     * @return la description associee aux personnages de la Room actuelle.
     */
    public String getCharacterDescription()
    {
        String vSortie = new String();
        if (this.aPersoList.getCharacterList().size() ==1){ // pour retirer le Dial de la liste
            vSortie += "\nVous etes tout seul ici, personne d'autre ne se trouve ici.\n";
        }
        else{
            vSortie += "\nVous etes accompagnes dans cette piece de :\n";
            vSortie += aPersoList.getCharacterListString();
        }
        return vSortie;
    } //get desc
    
    /**
     * Accesseur du nom de la Room
     * @return l'attribut du nom de la Room
     */
    public String getTitle()
    {
        return this.aTitle;
    } //get desc
    
    /**
     * Accesseur de l'inventaire de la Room
     * @return l'inventaire de la Room
     */
    public ItemList getLoot()
    {
        return aLoot;
    }
    
    /**
     * Accesseur de la liste des perso de la Room
     * @return la listes des persos de la Room
     */
    public CharacterList getPersonnages()
    {
        return aPersoList;
    }
    
    /**
     * Créer une nouvelle entree dans la HashMap de la Room
     * @param pRoom la Room a ajouter
     * @param pDirection la prochaine direction associee
     */
    public void setExits(final String pDirection, final Room pRoom )
    {
        aExits.put(pDirection,pRoom);
    }
    
    /**
     * /
     * Recherche des sorties dispo
     * @param pDirection la String de direction pour la prochaine Room
     * @return la piece dans la direction choisie
     */
    public Room getExit(final String pDirection)
    {
        return aExits.get(pDirection);
    }
    
    /**
     * Definit le nom de l'image associee a cette Room.
     * @param pString le nom de l'image a associer
     */
    public void setImageName(final String pString)
    {
        this.aImageName = pString;
    }
    
    /**
     * Recupere le nom de l'image associee a cette Room.
     * @return le nom de l'image associee a cette Room
     */
    public String getImageName()
    {
        return this.aImageName;
    }
    
    /**
     * /
     * Liste de sorties accessibles
     * @return la String des sorties de la pièce.
     */
    public String getExitString()
    {
        String vExitString ="\nSorties :";
        Set<String> vKeys = aExits.keySet();
        for (String vExit : vKeys) {
            vExitString += " "+ vExit;
        }
        return vExitString;
    }
}