import java.util.HashMap;
import java.util.Set;
/**
 * Classe FollowingCharacter - un lieu du jeu d'aventure Zuul.
 *
 * @author Njee Hettiarachchi
 */
public class FollowingCharacter extends AdvancedCharacter
{
    /**
     * Room du perso
     */
    private Player aPlayerToFollow =null;
    
    
    /**
     * Constructeur par defaut de la classe FollowingCharacter.
     * Initialise un nouvel objet FollowingCharacter avec un titre, une description et un message.
     * @param pName Le nom du FollowingCharacter.
     * @param pDescription La description du FollowingCharacter.
     */
    public FollowingCharacter(final String pName,final String pDescription)
    {
        super(pName,pDescription);
    }

    /**
     * Definit le joueur a suivre
     * @param pPlayer le joueur a suivre
     */
    public void setPlayerToFollow(final Player pPlayer)
    {
        this.aPlayerToFollow = pPlayer;
    }
    
    /**
     * Retourne le joueur suivi
     * @return le Player suivi
     */
    public Player getPlayerToFollow()
    {
        return this.aPlayerToFollow;
    }
    
    /**
     * Met a jour la Room ou se trouve le Character, apres avoir suivi le Player
     */
    public void updateRoom()
    {
        this.setInRoom(this.aPlayerToFollow.getRoom());
    }
    
    
}

