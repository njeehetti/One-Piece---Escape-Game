import java.util.HashMap;
import java.util.Set;

/**
 * Décrivez votre classe ItemList ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class ItemList
{
    
    /**
     * Liste des objets, associant chaque objet à une chaine de caracteres correspondante.
     */
    private HashMap<String, Item> aItemList;

    /**
     * Poids total cumule des objets.
     */
    private double aTotalWeight;

    /**
     * Poids total cumule des objets.
     */
    private double aAllowedMaxWeight;
    
    /**
     * Est ce que l'inventaire est accessible.
     */
    private boolean aIsOpenable;
    
    
    /**
     * Constructeur d'objets de classe ItemList
     */
    public ItemList()
    {
        // initialisation des variables d'instance
        aItemList = new HashMap<String,Item>();
        aIsOpenable = true;
    }
    
    /**
     * Verifie si l'inventaire peut etre accede (State Checker)
     * @return true si c'est possible, sinon false.
     */
    public boolean isOpenable()
    {
        return this.aIsOpenable;
    }
    
    /**
     *  desactive l'acces a l'inventaire.
     */
    public void makeNotOpenable()
    {
        this.aIsOpenable = false;;
    }
    
    /**
     * Active l'acces a l'inventaire.
     */
    public void makeOpenable()
    {
        this.aIsOpenable = true;
    }
    
    /**
     * Ajoute un element a la liste des objets et met à jour le poids total.
     * @param pItem L'element à ajouter à la liste.
     */
    public void setItemToList(final Item pItem)
    {
        aItemList.put(pItem.getTitle(),pItem);
        aTotalWeight += pItem.getPoids();
    }
    
    /**
     * Supprime un element de la liste des objets et met a jour le poids total.
     * @param pString La chaine correspondant a l'element a supprimer de la liste.
     */
    public void removeItemFromList(final String pString) {
        aTotalWeight -= this.getItemFromList(pString).getPoids();
        aItemList.remove(pString);
    }
    
    /**
     * Recupere un element de la liste des objets correspondant a la chaine donnee.
     * @param pString La chaine correspondant a l'element a recuperer de la liste.
     * @return L'objet correspondant a la chaine donnee.
     */
    public Item getItemFromList(final String pString)
    {
        return aItemList.get(pString);
    }
    
    /**
     * Renvoie la hashmap des objets 
     * @return La hashmap des objets .
     */
    public HashMap<String,Item> getItemList() {
        return aItemList;
    }
    
    /**
     * Renvoie la String des items compris dans l'inventaire
     * @return une string d'items.
     */
    public String getInventoryList() {
        String vSortie = new String();
        Set<String> vKeys = this.getItemList().keySet();
        for (String vItemName : vKeys) {
            vSortie += "\n- " + this.getItemFromList(vItemName).getItemString();
        }
        return vSortie;
    }
    
    
    /**
     * Renvoie le poids total cumule des objets
     * @return Le poids total cumule des objets
     */
    public double getTotalWeight()
    {
        return this.aTotalWeight;
    }
    
    /**
     * Modifie le poids total autorise des objets
     * @param pVal La nouvelle maximale de charge d'inventaire
     */
    public void setAllowedMaxWeight(final double pVal)
    {
        this.aAllowedMaxWeight = pVal;
    }
    
    /**
     * Renvoie le poids total autorise des objets
     * @return le poids total autorise des objets
     */
    public double getAllowedMaxWeight()
    {
        return this.aAllowedMaxWeight;
    }
}
