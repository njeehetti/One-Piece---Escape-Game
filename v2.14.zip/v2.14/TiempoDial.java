import java.util.HashMap;
import java.util.Set;
/**
 * Classe TiempoDial - un lieu du jeu d'aventure Zuul.
 *
 * @author Njee Hettiarachchi
 */
public class TiempoDial extends Item
{
    /**
     * Titre du sous Item.
     */
    private int aCountUse;
    
    
    
    /**
     * Constructeur par defaut de la classe TiempoDial.
     * Initialise un nouvel objet TiempoDial avec un titre, une description et un poids.
     * @param pTitle Le titre de l'Item.
     * @param pDescription La description de l'Item.
     * @param pPoids Le poids de l'Item.
     */
    public TiempoDial(final String pTitle,final String pDescription, final double pPoids)
    {
        super(pTitle,pDescription,pPoids);
        this.aCountUse = 5;
    }

    /**
     * Accesseur du compteur d'utilisation de TiempoDial
     * @return le compteur d'utilisation
     */
    public int getCountUse()
    {
        return this.aCountUse;
    }
    
    /**
     * Modificateur
     * Modifie le compteur d'utilisation
     * @param pVal ce qui sera ajoute au compteur
     */
    public void changeCountUse(final int pVal)
    {
        this.aCountUse = pVal;
    }
    
    /**
     * Modificateur (-1)
     * reduit le compteur d'utilisation
     */
    public void reduceCountUse()
    {
        this.aCountUse--;
    }
}

