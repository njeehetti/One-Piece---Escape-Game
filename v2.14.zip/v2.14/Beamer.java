import java.util.HashMap;
import java.util.Set;
/**
 * Classe Beamer - un lieu du jeu d'aventure Zuul.
 *
 * @author Njee Hettiarachchi
 */
public class Beamer extends Item
{
    /**
     * Titre de l'Item.
     */
    private Room aBeamer;
    
    /**
     * Indicateur de Charge
     */
    private boolean aIsCharged;
    
    /**
     * Constructeur par defaut de la classe Beamer.
     * Initialise un nouvel objet Beamer avec un titre, une description et un poids.
     * @param pTitle Le titre de l'Item.
     * @param pDescription La description de l'Item.
     * @param pPoids Le poids de l'Item.
     */
    public Beamer(final String pTitle,final String pDescription, final double pPoids)
    {
        super(pTitle,pDescription,pPoids);
        this.aBeamer = null;
        this.makeUsable();
    }

    /**
     * Accesseur de la Room de Beamer
     * @return l'attribut associe à la Room de charge
     */
    public Room getBeamerRoom()
    {
        return this.aBeamer;
    }
    
    /**
     * Modifie l'attribut associe à la Room de charge
     * @param pRoom la nouvelle piece de charge
     */
    public void setBeamerRoom(final Room pRoom)
    {
        this.aBeamer = pRoom;
    }
    
    
    /**
     * Accesseur de la charge du Beamer
     * @return l'attribut associe à la charge du Beamer
     */
    public boolean isCharged()
    {
        return this.aIsCharged;
    }
    
    /**
     * Modifie l'attribut associe à la charge du Beamer
     * @param pBool le nouvel etat de charge
     */
    public void setCharge(final boolean pBool)
    {
        this.aIsCharged = pBool;
    }
}

