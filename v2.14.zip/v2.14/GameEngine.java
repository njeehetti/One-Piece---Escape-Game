import java.util.Set;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

/**
 * Moteur du Jeu, comprenant les methodes primordiales a son fonctionnement.
 *
 * @author Mr Bureau &amp; Njee HETTIARACHCHI
 * @version 06.01.2024*/
public class GameEngine
{
    /**
     * Mots de direction valides.
     */
    private DirectionWords aDirectionWords;
    
    /**
     * Interface utilisateur.
     */
    private UserInterface aGui;
    
    /**
     * Analyseur de commandes.
     */
    private Parser aParser;
    
    /**
     * Joueur du jeu.
     */
    private Player aPlayer ;
    
    /**
     * Ensemble des pieces du Jeu
     */
    private static HashMap<String, Room> aRoomList= new HashMap<>(); //Car nous avons besoin de cet attribut dans la classe TransporterRoom, sans avoir a instancier GameEngine
    
    /**
     * Ensemble des enigmes du Jeu
     */
    private HashMap<String, String> aEnigmeList = new HashMap<>();
    
    
    /**
     * Autorise ou pas les commandes de test
     */
    private boolean aIsTestRunning = false; // car son état doit changer sur plusieurs methodes
    
    /**
     * Contiendra le piece ou se rendre par defaut pour l'execution de test (cas des Transporter Room)
     */
    private Room aAleaRoom = null; 
    
    /**
     * Piece de demarrage du jeu
     */
    private Room aBaseRoom =null;
    
    /**
     * Piece mystere du jeu
     */
    private Room aEasterEgg =null;
    
    /**
     * Initialiser du temps de jeu
     */
    private final int ONE_SECOND = 1000; // pour set le refresh time a 1 seconde
    
    /**
     * Minuteur du jeu
     */
    private Timer aGameTimer;
    
    /**
     * Temps restant a jouer
     */
    private int aGameTime_Left;
    
    
    /**
     * Minuteur du Coup de Burst
     */
    private Timer aBurstTimer;
    
    /**
     * Temps restant avant le coup de Burst final
     */
    private int aBurstTimerCountdown;
    
    /**
     * Combinaison du coffre a trouver par l'utilisateur
     */
    private String aCombination = new String();
    
    /**
     * Condition finale de reussite du jeu
     */
    private boolean aIsEngineSet = false;
    
    /**
     * Condition finale d'affichage des commandes ultimes
     */
    private boolean aIsFinalMoment = false;
    
    /**
     * Reussite du jeu ?
     */
    private boolean aHasWon = false;
    
    /**
     * Echec du jeu ?
     */
    private boolean aHasLost = false;
    
    /**
     * Personnage d'avancement dans la quete du jeu / Tasks
     */
    private FollowingCharacter aDial = null;
    
    //Ensemble de checkers pour le quest Updater 
    
    /**
     * Avancement dans la quete du jeu
     */
    private int aQuestProgress = -1;
    
    /**
     * Task0
     */
    private boolean aHasSpokenToNami =false;
    
    /**
     * Task1
     */
    private boolean aHasSpokenToRobin =false;

    /**
     * Task2
     */
    private boolean aHasGivenToZoro =false;

    /**
     * Task2
     */
    private boolean aHasGotCola =false;
    
    /**
     *  Création des rooms, des directions et du parser, responsable du traitement des saisies utilisateurs
     */
    public GameEngine()
    {   
        this.aPlayer = new Player(javax.swing.JOptionPane.showInputDialog( "Quel est ton prenom ?" )); 
        if (this.aPlayer.getName().equals(""))
            aPlayer.setName("Bonney");
        createGameElements();
        this.aCombination = codeAleatoire();
        aDirectionWords = new DirectionWords();
        aParser = new Parser();
        //startTimerCountDown();
    }
    
    /**
     * Definit l'interface utilisateur et affiche une image d'accueil.
     * @param pUserInterface L'interface utilisateur à definir.
     */
    public void setGUI ( final UserInterface pUserInterface )
    {
        this.aGui = pUserInterface;
        //this.aGui.enable(false);
        this.aGui.showImage( "home.jpeg" );
        this.printWelcome();
    }
    
    /**
     * Genere aleatoirement un code pour le cadenas du coffre.
     * @return le code genere aleatoirement
     */
    public String codeAleatoire()
    {
        Random vRand = new Random();
        StringBuilder codeBuilder = new StringBuilder(); // trouvé sur stackoverflow pour construire une String en associant des chiffres
        for (int i = 0; i < 4; i++) {
            int chiffre = vRand.nextInt(9) + 1; // Générer un chiffre aléatoire de 1 à 9
            codeBuilder.append(chiffre);
        }
        return codeBuilder.toString();
    }
    
    /**
     *  Montre un message d'accueil a l'utilisateur
     */
    public void printWelcome()
    {
        //this.aGui.showImage("");
        //this.aGui.enable(true);
        this.aGui.println(" ");
        this.aGui.println("Salutations, "+ this.aPlayer.getName() + ", bienvenue sur Celestial Escape!");
        this.aGui.println(" ");
        this.aGui.println("Vous demarrez votre aventure sur le Thousand Sunny, bateau pirate du Yonko Monkey D Luffy!");
        this.aGui.println("L'equipage reprend la mer apres une escale sur l'ile Scientifique de Vegapunk");
        this.aGui.println("Votre mission est de vous sauver d'une attaque ennemie de la Marine, vous n'avez que 15 minutes pour y arriver!");
        this.aGui.println("Pour cela, explorez les pièces du bateau, communiquez avec les membres de l'equipage et trouvez un moyen de vous enfuir!");
        this.aGui.println("\nN'hesitez pas a interagir avec votre Dial de Communication pour avancer dans la quete principale\n");
        this.aGui.println("Tapez 'start' pour lancer le jeu! ");
        this.aGui.println("Tapez 'help' si vous avez besoin d'aide :)");
        this.aGui.println("Vous pouvez abandonner a tout moment avec 'quit', mais ce n'est pas le but du jeu :)");
        this.aGui.println("\n\nPS :Profitez de la multitude de boutons pour jouer avec aisance au jeu xD\n");
        this.aGui.println(" ");
    }
    
    /**
     *  Création des pièces de la Map, ainsi que des sorties associées à chacun d'entre elles
     */
    private void createGameElements()
    {
        aRoomList = new HashMap<String,Room>();
        
        Room vPonton = new Room("Pont superieur", "sur le grand pont superieur du Thousand Sunny, zone centrale ou l'equipage passe la plupart de son temps lorsqu'ils sont en mer!\nD'ici vous pouvez apercevoir des membres de l'equipage en train de pecher des gros poissons. \nQui sait s'ils seront destines a finir dans l'Aquarium, ou plutot terminer dans les casseroles du chef cuisinier!");
        aRoomList.put(vPonton.getTitle(),vPonton);
        
        Room vPasserelleLat = new Room("Passerelle", "sur une passerelle surelevee reliant le pont central a l'arriere du bateau, et permettant ainsi d'acceder aux etages superieurs.");
        aRoomList.put(vPasserelleLat.getTitle(), vPasserelleLat);
        
        TransporterRoom vCuisine = new TransporterRoom("Cuisine", "arrive a l'espace favori du capitaine Luffy, la ou il a l'occasion de deguster des mets d'exception, prepares par le grand chef cuisiner Sanji :)");
        aRoomList.put(vCuisine.getTitle(), vCuisine);
        
        Room vAtelier = new Room("Atelier", "au repaire secret du grand guerrier des mers Usopp! Au milieu de ses maintes petites bricoles, prenez place pour vous preparer a entendre le plus grand recit (mytho) que l'on ne vous ai jamais raconte!");
        aRoomList.put(vAtelier.getTitle(), vAtelier);
        
        Room vPropulseur = new Room("Salle des Engins de Propulsion", "dans la piece maitresse du Thousand Sunny. La ou on passe aux choses serieuses!\nC'est ici que se trouve le moteur a propulsion du bateau, qui en etant active permet de se projeter dans les airs a plus de 1km! Tres utile si vous cherchez a vous echapper d'une situation tendue");
        aRoomList.put(vPropulseur.getTitle(), vPropulseur);
        
        Room vInfirmerie = new Room("Infirmerie", "au coin des blesses! Tout bateau de grand equipage se doit de posseder un medecin a bord pour soigner ses pirates!\nNe vous inquietez pas, s'il vous arrivait quoi que ce soit, le medecin trouvera un moyen de vous remettre sur pied :)\n(Meme si vous lui causerez la peur de sa vie...)\n\nCela dit, quelque chose vous derange dans cette piece : la taille immense du mirror qui se trouve en face de vous. Attendez mais,  vous n'y auriez pas vu passer une vague silhouette a l'instant??\n\nPeut etre que vous aussi, vous devriez vous faire soigner hahahaha xD");
        aRoomList.put(vInfirmerie.getTitle(), vInfirmerie);
        
        Room vBarAquarium = new Room("Bar & Aquarium", "dans l'espace de detente du bateau, la ou vous pourrez observer les poissons repeches par Luffy et Usopp et qui desormais patotent dans l'immense Aquarium!\nUn minibar accompagne egalement cette piece, afin que vous puissiez vous rafraichir le gosier tout en profitant de ce havre de paix :)");
        aRoomList.put(vBarAquarium.getTitle(), vBarAquarium);
        
        TransporterRoom vProue = new TransporterRoom("Proue", "a l'endroit le plus avant du bateau, juste derriere la proue en forme de lion ou le capitaine a tendance a se poser pendant que le Sunny vogue sur les mers!");
        aRoomList.put(vProue.getTitle(), vProue);
        
        Room vPoupe = new Room("Poupe", "au niveau arriere du bateau, la ou se trouve notamment la barre de gouvernail.\nUn conseil : ne laissez jamais Luffy s'en approcher");
        aRoomList.put(vPoupe.getTitle(), vPoupe);
        
        Room vPosteObservation = new Room("Observatoire", "au niveau du poste d'observation du Sunny.\nD'ici vous pourrez obsever les zones environantes a la recherche de nouvelles iles, de navires pirates environants, ou meme pour anticiper de futures tempetes");
        aRoomList.put(vPosteObservation.getTitle(), vPosteObservation);
        
        Room vHangarReserve = new Room("Reserve", "toujours au niveau inferieur du bateau, la ou sont stockes les rations alimentaires de l'equipage, ainsi que toute sorte de ressources. Un coffre scelle s'y trouve egalement, pourquoi ne pas essayer de l'ouvrir?");
        aRoomList.put(vHangarReserve.getTitle(), vHangarReserve);
        
        Room vSalleEntrainement = new Room("Training", "dans la salle d'entrainement musculaire du bateau.\nA vrai dire, seul Zoro vient frequenter cette piece pour developper davantage sa force physique et donc ameliorer le maniement de ses 3 sabres.");
        aRoomList.put(vSalleEntrainement.getTitle(), vSalleEntrainement);
        
        Room vFoyer = new Room("Foyer", "dans la piece de reunion de l'equipage, la ou il leur arrive de prendre des decisions strategiques pour la suite de leurs aventures.\nC'est egalement ici que sont affichees les primes de chaque membre.");
        aRoomList.put(vFoyer.getTitle(), vFoyer);
        
        Room vBibliotheque = new Room("Biblio", "au niveau des archives, dans la grande bibliotheque de Robin, qui stocke ici des parchemins et autres bouqins ancients afin de dechiffrer les codes les plus compliques : ceux a base de Poneglyphes!");
        aRoomList.put(vBibliotheque.getTitle(), vBibliotheque);
        
        aEasterEgg = new Room("Monde des Miroirs", "dans un vaste lieu mysterieux rempli de miroirs magiques qui offrent des deplacements instantanes entre differents endroits, vous l'aurez compris à travers les mirroirs comme celui que vous avez emprunte grace a la relique enchantee.");    
        
        
        
        //Creation des Items
        
        
        Beamer vBeamerA = new Beamer ("BeamerA","Un outil confectionne par le Dr Vegapunk et qui permettrait de faire des... sauts dimensionnels?",3);
        Beamer vBeamerB = new Beamer ("BeamerB","Un outil confectionne par le Dr Vegapunk et qui permettrait de faire des... sauts dimensionnels?",3);
        Item vChapeau = new Item ("StrawHat","Le chapeau livre a Luffy par l'empereur Shanks",3);
        Item vLunette = new Item ("Binocles","Lunettes de vue utilisee afin d'observer les environs",2);
        Item vBranche = new Item ("Branche","Un vulgaire bout de branche tombee par terre, sans explication particuliere",1);
        Item vHaltere = new Item ("Haltere","Zoro s'en sert pour ses entrainements de maniement de sabre",15);
        Item vCookie = new Item ("Cookie","Servi par le cuistot Sanji, ce cookie vous donnera l'impression d'etre plus fort que jamais!", 1);
        Item vViande = new Item("Viande", "Avec son appetit de geant, Luffy la devorerait en un instant ", 4);
        Item vCola = new Item("Cola", "La boisson energisante de reference pour les membres de l'equipage mais aussi... pour le... bateau!",2);
        TiempoDial vTiempoA = new TiempoDial("ShortTiempoDial", " Usopp a tente de confectionner une version simplifiee du TiempoDial mais plus resistante, pour pouvoir l'utiliser plusieurs fois",1);
        TiempoDial vTiempoB = new TiempoDial("TiempoDial", "La toute derniere invention du maitre de la Science, le fameux Dr Vegapunk! Cet engin permettrait de... remonter dans le temps?\nAttention tout de meme, cet objet peut etre tres instable, servez vous en uniquement au moment ou cela comptera vraiment.",1);
        
        
        vCookie.makeOneTimeUsable();
        vTiempoB.makeOneTimeUsable();
        vTiempoA.makeUsable();
        
        // Creation des Enigmes
        
        
        ItemToRead vEnigmeA = new ItemToRead ("EnigmeA","Combien de personnes ont rejoint Luffy dans sa grande aventure?",1); //9 X
        aEnigmeList.put("9","EnigmeA");
        vEnigmeA.makeUsable();
        ItemToRead vEnigmeB = new ItemToRead ("EnigmeB","Combien de membres de l'equipage a mange un fruit du Demon?",1); //4 X
        aEnigmeList.put("4","EnigmeB");
        vEnigmeB.makeUsable();
        ItemToRead vEnigmeC = new ItemToRead ("EnigmeC","Combien de Vivre Card l'equipage possede t'il actuellement ?",1); //1 X
        aEnigmeList.put("1","EnigmeC");
        vEnigmeC.makeUsable();
        ItemToRead vEnigmeD = new ItemToRead ("EnigmeD","Combien de sabres manie Zoro?",1); //3 X
        aEnigmeList.put("3","EnigmeD");
        vEnigmeD.makeUsable();
        ItemToRead vEnigmeE = new ItemToRead ("EnigmeE","Durant ses aventures, combien de primes differentes ont ete placees sur la tete de Luffy?",1); // 6
        aEnigmeList.put("6","EnigmeE");
        vEnigmeE.makeUsable();
        ItemToRead vEnigmeF = new ItemToRead ("EnigmeF","Combien de membres de l'equipage de Luffy ont ete recrutes avant l'entree dans le Nouveau Monde ?",1); //8 X
        aEnigmeList.put("8","EnigmeF");
        vEnigmeF.makeUsable();
        ItemToRead vEnigmeG = new ItemToRead ("EnigmeG","Quel est le nombre de membres de l'equipage de Luffy possedant un passé de pirate avant de rejoindre l'équipage ?",1); //2
        aEnigmeList.put("2","EnigmeG");
        vEnigmeG.makeUsable();
        ItemToRead vEnigmeI = new ItemToRead ("EnigmeI","Quel est le nombre de personnages masculins dans l'equipage?",1); //7 X
        aEnigmeList.put("7","EnigmeI");
        vEnigmeI.makeUsable();
        ItemToRead vEnigmeJ = new ItemToRead ("EnigmeJ","Combien de GEARS a Luffy?",1); //5 X
        aEnigmeList.put("5","EnigmeJ");
        vEnigmeJ.makeUsable();
    
        
        //Moving Character qui suivra le joueur dans chaque piece et qui rappellera les objectifs a atteindre quand on voudra lui parler
        aDial = new FollowingCharacter("Dial", "Aussi connu sous le nom Den Den Mushi, ce coquillage est en realite un engin portatif de communication. Ce dernier, que vous aurez toujours dans votre poche, vous indiquera vos missions a realiser au fil de votre progression, afin de sauver l'equipage!");
        
        //Differents messages d'avancement
        aDial.setMessage(-1,"Liaison desactivee : Echec lors de la retransmission des messages \n\nPour toute assistance, veuillez vous rendre au Poste d'Observation et parler a Nami");
        aDial.setMessage(0,"Robin se trouve au niveau de la Bibliotheque, tu peux t'y rendre en descendant du Bar de l'autre cote du Pont Central \nEvite d'aller discuter avec les autres pour le moment, ils n'ont pas l'air d'avoir conscience de ce qui passe donc ne perds pas de temps. \nDecidemment, on ne peut compter que sur les femmes a bord!");
        aDial.setMessage(1,"Zoro a oublie une de ses halteres d'entrainements sur le Pont Central, mais il va te falloir autre chose que ta propre force pour que tu puisses la soulever!\n\nRends toi a la cuisine et regarde s'il reste encore des Cookie a Don de Force prepares par Sanji, ca pourrait t'etre d'une grande aide :)\n\nVa ensuite le retrouver dans sa salle d'entrainement, juste a cote du poste d'observation de Nami");
        aDial.setMessage(2,"Maintenant que tu sais quelles enigmes chercher, tu vas devoir te balader partout sur le bateau a la recherche de ces dernieres.\nN'hesites pas a communiquer avec les autres membres d'equipages, ils auront peut etre les reponses necessaires pour les solutions.\n\nUne fois collectee, rends toi a la Reserve dans la calle pour deverouiller le coffre. Les enigmes t'etaient donnees dans un ordre aleatoire, donc il va falloir essayer differentes combinaisons! Il se peut egalement que le meme chiffre apparaisse plusieurs fois dans le code\n\nPour rappel: vous pouvez reconsulter la liste des enigmes avec le Guide ajoute a votre inventaire");
        aDial.setMessage(3,"Maintenant que tu as de quoi demarrer l'Engin de Propulsion, rends toi a la salle des machines dans la calle et utilise le Cola pour tous nous sortir d'ici!");
        
        //Creation des Characters
        
        Character vLuffy = new Character("Luffy", "Capitaine de l'equipage du Chapeau de Paille. Joyeux, naif mais reveur, il possede le pouvoir du Fruit du Caoutchou, lui donnant un corps élastique.");
        vLuffy.setMessage("Salut "+this.aPlayer.getName()+"! C'est plutot une belle journee aujourd'hui :) Tu sais, si je me pose toujours à l'avant du bateau parce que c'est là que tout commence, nakama! C'est comme être face à l'inconnu, sentir le vent sur mon visage et la mer qui s'étend à perte de vue. C'est l'aventure, tu vois? \n\nEn se tenant à l'avant, on dit au monde entier qu'on est prêts à tout! C'est ca l'esprit d'aventure Hahaha\n\nOn en a explore, des endroits plus etranges que les autres depuis le debut de l'aventure, comme le monde des mirroirs de notre amie Branche hahah \n(Note au joueur: En realite elle s'appelait Brulee et c'etait une ennemie... mais bon, Luffy pensera toujours que les gens seront ses amis xD)\n\nBrook et Jimbei nous ont meme rejoins en cours de chemin alors meme qu'ils avaient une experience de pirate avant nous, mais au final on est tous la pour reigner sur les Mers et manger beauuucoup de viande Hihihihii");
        
        Character vZoro = new Character("Zoro", "Le bretteur talentueux et bras droit de Luffy. Depourvu de sens d'orientation mais pragmatique, il manie trois sabres et vise a devenir le meilleur sabreur du monde.");
        vZoro.setMessage("Je t'ai deja dit de ne pas me deranger pendant mon entrainement ! Maintenant que notre capitaine Luffy a atteint son nouveau pallier de puissance avec son GEAR 5, je dois me surpasser et atteindre un niveau digne d'un bras droit d'empereur des Mers!");
        
        Character vNami = new Character("Nami", "Navigatrice de l'équipage. Souvent nichee dans son poste d'obesevration, elle est experte en cartographie et aspire a dessiner une carte complete du monde.");
        vNami.setMessage("Parfait! C'est bien ce que je me disais... Quelque chose d'etrange se trame.\nJe crois que notre couverture a ete grillee, un pavillon de la Marine se dirige droit vers notre bateau, il faut faire vite!\n\nVa trouver Robin en bas un peu plus loin sur le bateau, elle saura nous aider. Mais juste avant, je vais configurer ton Dial pour que tu puisses interagir avec nous et savoir tout ce que tu dois faire. Je prefere rester ici pour continuer a surveiller les environs");
        
        Character vUsopp = new Character("Usopp", "Le sniper menteur. Il est habile a la fois avec un lance-pierres et comme tireur d'elite et reve de devenir un valeureux guerrier des mers.");
        vUsopp.setMessage("Ah ! T'as entendu parler des primes de Luffy recemment ? C'est... c'est terrifiant, je vous le dis ! \nAvec sa 6eme prime qui culmine a 3 MILLIARDS de Berrys, et son nouveau titre d'empereur, qui sait ce qui pourrait nous tomber dessus!\n\nJe veux dire, moi, Usopp, le grand guerrier des mers, je prefere encore affronter un millier de pirates d'eau douce que de me retrouver dans le viseur du Gouvernement Mondial !\n\nMais regarde ca, j'ai un tas de petits gadgets pour me defendre, mon atelier en est rempli!\n Je veux dire, moi, Usopp, le grand guerrier des mers, suis l'homme de la situation si jamais il vous arrive une galere! (Clin d'oeil alors qu'il ne semble pas tres serein en disant ca...)" );
        
        Character vSanji = new Character("Sanji", "Cuisinier de talent et combattant redoutable. Grand fervant de la gente feminine, il possede un style de combat base sur les arts martiaux et cherche la mer legendaire, All Blue.");
        vSanji.setMessage("Ah cher ami, laisse-moi te parler de deux choses qui font battre mon cœur : les femmes et la cuisine.\n\nNami swannnnnnnnn\nRobin chwannnnnnn !\nQuel homme chanceux je suis, de pouvoir cotoyer ces beautes au quotidien, a satisfaire leur desirs culinaires! Mais ne t'en fais pas, j'ai aussi du succes avec bien d'autres demoiselles! \n\nRegarde par exemple, j'ai en ma possession la Vivre Card de Lola, une femme aussi mystérieuse que délicieuse.\nEt selon moi: avoir la Vivre Card de quelqu'un, c'est comme avoir le secret pour trouver le chemin vers son coeur! Bref, peu importe ou menent les vents de la mer, je serai toujours la, pret a concocter des plats delicieux pour mes precieuses dames !");
        
        Character vChopper = new Character("Chopper", "Medecin et renne aux capacites speciales. Il a mange le Fruit de l'Hito Hito no Mi, lui permettant de se transformer en differentes formes et veut devenir un grand medecin.");
        vChopper.setMessage("En tant que plus jeune, c'est parfois un peu bizarre, mais je fais de mon mieux pour soigner tout le monde et rendre l'equipage en pleine forme !\nEt vous savez quoi ? J'adore les bonbons ! C'est mon petit plaisir secret. Quand je ne suis pas en mode docteur, vous me trouverez probablement en train de grignoter quelque chose dans la cuisine.\n\nJ'adore y savourer les Cookie de Sanji, ils sont plus doux que mes Rumble Ball mais j'ai l'impression qu'ils me rendent tout aussi fort! Mais chuuuut, c'est notre secret !\n");
        
        Character vRobin = new Character("Robin", "Archeologue et historienne. Elle a mange le Fruit du Flore, lui permettant de produire des parties de son corps comme des fleurs et veut découvrir la veritable histoire du monde.");
        vRobin.setMessage("Ah, bonjour! Nami vient de m'informer qu'elle avait detecte une menace ennemie en approche. Les garcons semblent totalement ignorer ce qui se passe, je pense que c'est du au fait qu'ils soient tous hypnotises par le chant des sirenes environnant ces mers douces.\n\nJ'ai intercepte plusieurs messages de navires de la Marine : depuis que Luffy a ete nomme Empereur des Mers, tout le monde veut sa tete! On n'a pas le choix, dans l'etat actuel des garcons il va falloir se servir du Coup de Burst tout seul!\n\nLes bouteilles de Cola necessaires pour le propulseur se trouve dans un coffre dans la Reserve, mais pour le debloquer il va falloir que t'obtiennes la bonne combinaison. Zoro devrait te passer une notice avec les bonnes enigmes, mais d'abord il faudra que tu rendes service en lui rapportant son haltere!\n\nAh et dernier conseil : va rendre visite a notre cher Usopp dans son Atelier: il a confectione plusieurs objets qui pourrait t'etre d'une grande utilite pour tes deplacements et la gestion du temps.\n\nJe te tiendrai au courant sur le reste des objectifs via ton Dial.\nBonne chance");
        
        Character vFranky = new Character("Franky", "Charpentier naval et cyborg. Il est specialise dans la construction navale et a transforme une grande partie de son corps en cyborg.");
        vFranky.setMessage("Yoooo, "+this.aPlayer.getName()+"! C'est moi, le suuuupeeeeer general Franky, le maitre de la charpenterie!\n" +
                            "Regardez-moi, avec mes bras surdimensionnes et mes lunettes de soleil stylees. Je suis une force de la nature, le gars qui peut transformer le Sunny en un veritable vaisseau de la SUPER classe !\n" +
                            "Et parlons de mes jouets, ou devrais-je dire, de mes armes ! Le Radical Beam, le Coup de Vent, le Rocket Launcher... c'est du Franky, tout ça !\n\n" +
                            "Parlons du suuuupeeer Coup de Burst, le truc le plus suuuuuper du Thousand Sunny ! Vous avez deja vu un bateau voler ? Non ? Eh bien, accrochez-vous bien, parce que c'est ce que fait le Sunny avec le coup de burst, propulse par le pouvoir du cola, ouais !\n"+
                            "Vous savez, etre le charpentier du Roi des Pirates, ça demande des competences et du style. Mais moi, Franky, j'ai les deux !\n");
        
        Character vBrook = new Character("Brook", "Musicien et épéiste squelette. Il est devenu un squelette vivant après avoir mange le Fruit de la Resurrection et est a la recherche de la promesse faite a son ancien capitaine.");
        vBrook.setMessage("Yohohohoooo!\nJe fus le 8eme et dernier membre a rejoindre l'equipage avant notre arrivee sur le Nouveau Monde. Mais depuis ce moment j'ai l'impression de renaitre, avec toute cette bonne ambiance et nos deux jolies nanas!\nMeme Jimbei, le dernier a nous avoir rejoint après moi, est d'accord sur le fait que cet equipage et les aventures qu'on y vit sont d'une rarete unique! \n\nLuffy deviendra bel et bien le Roi des Pirates, saches-le!\nTiens, je vais un morceau de musique a ce sujet! A plus tard!");
        
        Character vJimbei = new Character("Jimbei", "Ancien Capitaine des Pirates du Soleil. Etant un Homme-poison temeraire, ce puissant combattant aquatique est capable de manipuler l'eau et donc gerer si besoin les courants marins pour les deplacements du Bateau.");
        vJimbei.setMessage("La mer, c'est toute ma vie. Chaque courant, chaque maree, ils portent les histoires des peuples que j'ai rencontres, des amis que j'ai perdus, et des batailles que j'ai menees.\n\nLuffy et son equipage m'ont accueilli a bras ouverts, et ensemble, nous avons cree des liens indefectibles.\n\nNous avons partage des rires, des larmes, et nous avons defendu nos ideaux. Chacun d'entre nous est une vague unique dans cette mer infinie, et notre navire avance avec la force combinee de nos rêves:)\n\nLes Chapeaux de Pailles ont sauve mon peuple, et pour cela je donnerai meme de ma vie s'il le fallait, pour qu'ils puisse continuer leur histoire, Notre Histoire!!");
        
        
        // initialiser les sorties de chaque room, ainsi que leur image
        // ET ajout des Items et Characters aux Rooms
        
        vPonton.setImageName("ponton.jpeg");
        vPonton.setExits("north",vBarAquarium);
        vPonton.setExits("escaliers_avant",vProue);
        vPonton.setExits("escaliers_arriere",vPasserelleLat);
        vPonton.setExits("south",vFoyer);
        vPonton.getPersonnages().setCharacterToList(vBrook);
        vPonton.getLoot().setItemToList(vEnigmeF);
        vPonton.getLoot().setItemToList(vEnigmeG);
        vPonton.getLoot().setItemToList(vHaltere);
        
        vProue.setImageName("front.jpeg");
        vProue.setExits("south",vPonton);
        vProue.setExits("down",vBarAquarium);
        vProue.getPersonnages().setCharacterToList(vLuffy);
        vProue.getLoot().setItemToList(vBranche);
        
        vBarAquarium.setImageName("bar.jpg");
        vBarAquarium.setExits("up",vProue);
        vBarAquarium.setExits("south",vPonton);
        vBarAquarium.setExits("down",vBibliotheque);
        vBarAquarium.getPersonnages().setCharacterToList(vJimbei);
        vBarAquarium.getLoot().setItemToList(vEnigmeI);
        
        vBibliotheque.setImageName("biblio.jpeg");
        vBibliotheque.setExits("up",vBarAquarium);
        vBibliotheque.setExits("south",vHangarReserve);
        vBibliotheque.getPersonnages().setCharacterToList(vRobin);
        vBibliotheque.getLoot().setItemToList(vBeamerB);
        vBibliotheque.getLoot().setItemToList(vEnigmeB);
        
        vHangarReserve.setImageName("entrepot.jpeg");
        vHangarReserve.setExits("north",vBibliotheque);
        vHangarReserve.setExits("south",vPropulseur);
        vHangarReserve.getLoot().setItemToList(vCola);
        vHangarReserve.getLoot().makeNotOpenable();
        
        vPropulseur.setImageName("propulseur.jpeg");
        vPropulseur.setExits("north",vHangarReserve);
        vPropulseur.setExits("up",vFoyer);
        
        vFoyer.setImageName("foyer.jpeg");
        vFoyer.setExits("down",vPropulseur);
        vFoyer.setExits("north",vPonton);
        vFoyer.setExits("south",vCuisine);
        vFoyer.getLoot().setItemToList(vEnigmeA);
        vFoyer.getLoot().setItemToList(vEnigmeE);
        
        vCuisine.setImageName("cuisine.png");
        vCuisine.setExits("north",vFoyer);
        vCuisine.getLoot().setItemToList(vCookie);
        vCuisine.getLoot().setItemToList(vEnigmeJ);
        vCuisine.getPersonnages().setCharacterToList(vSanji);
        
        vPasserelleLat.setImageName("passerelle.png");
        vPasserelleLat.setExits("escaliers",vPonton);
        vPasserelleLat.setExits("west",vInfirmerie);
        vPasserelleLat.setExits("south",vPoupe);
        
        vInfirmerie.setImageName("medbay.jpeg");
        vInfirmerie.setExits("east",vPasserelleLat);
        //vInfirmerie.setExits("north",vEasterEgg);
        vInfirmerie.getPersonnages().setCharacterToList(vChopper);
        vInfirmerie.getLoot().setItemToList(vEnigmeC);
        
        vAtelier.setImageName("atelier.jpg");
        vAtelier.setExits("north",vInfirmerie);
        vAtelier.setExits("east",vPoupe);
        vAtelier.getLoot().setItemToList(vBeamerA);
        vAtelier.getLoot().setItemToList(vTiempoA);
        vAtelier.getLoot().setItemToList(vLunette);
        vAtelier.getPersonnages().setCharacterToList(vUsopp);
        
        vPoupe.setImageName("franky.png");
        vPoupe.setExits("west",vAtelier);
        vPoupe.setExits("north",vPasserelleLat);
        vPoupe.setExits("up",vPosteObservation);
        vPoupe.getPersonnages().setCharacterToList(vFranky);
        
        vPosteObservation.setImageName("observation_center.jpg");
        vPosteObservation.setExits("north",vSalleEntrainement);
        vPosteObservation.setExits("down",vPoupe);
        vPosteObservation.getLoot().setItemToList(vChapeau);
        vPosteObservation.getLoot().setItemToList(vLunette);
        vPosteObservation.getPersonnages().setCharacterToList(vNami);
        
        vSalleEntrainement.setImageName("zoro_salle.jpeg");
        vSalleEntrainement.setExits("south",vPosteObservation);
        vSalleEntrainement.getPersonnages().setCharacterToList(vZoro);
        vSalleEntrainement.getLoot().setItemToList(vEnigmeD);
        
        aEasterEgg.setImageName("easteregg.jpeg");
        aEasterEgg.setExits("mirror",vInfirmerie);
        aEasterEgg.getLoot().setItemToList(vCola);
        aEasterEgg.getLoot().setItemToList(vTiempoB);
        
        this.aBaseRoom = vPosteObservation;
        aPlayer.setInRoom(aBaseRoom);
        aDial.setRoom(aBaseRoom);
        aDial.setPlayerToFollow(aPlayer);
        aBaseRoom.getPersonnages().setCharacterToList(aDial);
        //aDial.setInRoom(aPlayer.getRoom());
    }
    
    /**
     *  Accesseur de la Room où se situe le Player
     *  @return la Current Room du Player
     */
    public Room getRoom()
    {
        return this.aPlayer.getRoom();
    }
    
    /**
     *  Accesseur de la Room où se situe le Player
     *  @return la Current Room du Player
     */
    public static HashMap<String,Room> getRoomList()
    {
        return aRoomList; //Pas besoin de this car aRoomList est static
    }
    
    /**
     *  Accesseur de la condition d'utilisation du coup de burst
     *  @return true si c'est vrai, non sinon
     */
    public boolean getIsEngineSet()
    {
        return aIsEngineSet; 
    }
    
    
    /**
     *  Traitement de la commande donnee par saisie utilisateur
     *  @param pCommandLine la commande a etre interpretee
     */
    public void interpretCommand(final String pCommandLine)
    {
        this.aGui.println("> " + pCommandLine);
        Command vCommand = this.aParser.getCommand( pCommandLine );
        this.aDial.updateRoom(); // Le joueur va rejoindre le Player dans la piece ou il se trouve
        
        
        if (vCommand.isUnknown()){
            this.aGui.println("Je ne comprends pas ce que vous avez tape au clavier...");
            this.aGui.println("Veuillez retenter une saisie");
            return;
        }
        
        String vCommandWord = vCommand.getCommandWord();
        
        if (!aIsFinalMoment){
            if (vCommandWord.equals("go")){
                goRoom(vCommand);
                
            }
            
            else if (vCommandWord.equals("help")){
                this.printHelp();
    
            }
            else if (vCommandWord.equals("look")){
                if (vCommand.hasSecondWord()){
                    this.lookItem(vCommand.getSecondWord());
                    if (aGui.isPlayerMenuOpened())
                        this.aGui.changePlayerMenuState();
                }
                else{
                    this.look();
                    if (aGui.isPlayerMenuOpened())
                        this.aGui.changePlayerMenuState();
                }
            }
            
            else if (vCommandWord.equals("take")){
                if (vCommand.hasSecondWord()){
                    this.take(vCommand.getSecondWord());
                    //this.aGui.changePlayerMenuState(); /: rester sur le menu des actions
                    this.aGui.changeListState();
                    
                }
                else{
                    this.aGui.println("Take quoi?\n");
                    
                }
            }
            
            else if (vCommandWord.equals("drop")){
                if (vCommand.hasSecondWord()){
                    this.drop(vCommand.getSecondWord());
                    //this.aGui.changePlayerMenuState();
                    this.aGui.changeListState();
                    
                }
                else{
                    this.aGui.println("Drop quoi?\n");
                    
                }
            }
            else if (vCommandWord.equals("unlock")){
                if (roomIs("Reserve"))
                {
                    this.unlock();
                    //this.aGui.changePlayerMenuState();
                }
                else 
                    this.aGui.println("Commande indisponible ici\n");
                
            }
            
            else if (vCommandWord.equals("use")){
                if (vCommand.hasSecondWord()){
                    this.use(vCommand.getSecondWord());
                    //this.aGui.changePlayerMenuState();
                    this.aGui.changeListState();
                    
                }
                else{
                    this.aGui.println("Use what?\n");
                    
                }
            }
            else if (vCommandWord.equals("give")){
                if (roomIs("Training"))
                {
                    this.give();
                    //this.aGui.changePlayerMenuState();
                }
                else 
                    this.aGui.println("Commande indisponible ici\n");
                
            }
            
            else if (vCommandWord.equals("talk")){
                if (vCommand.hasSecondWord()){
                    this.talk(vCommand.getSecondWord());
                    //this.aGui.changePlayerMenuState();
                    this.aGui.changeListState();
                    
                }
                else{
                    this.aGui.println("Talk to Who?\n");
                    
                }
            }
            
            else if (vCommandWord.equals("start")){
                this.start();
                
            }
            
            else if (vCommandWord.equals("inventory")){
                this.inventory();
                if (aGui.isPlayerMenuOpened())
                    this.aGui.changePlayerMenuState();
                
            }
            
            else if (vCommandWord.equals("back")){
                this.back();
                
            }
            
            else if (vCommandWord.equals("playerActions")){
                this.aGui.changePlayerMenuState();
                
            }
            
            else if (vCommandWord.equals("itemlist")){
                this.aGui.changePlayerMenuState();
                this.aGui.changeListState();
                
            }
            
            else if (vCommandWord.equals("returnPlayerActions1")){
                this.aGui.changePlayerMenuState();
                
            }
            
            else if (vCommandWord.equals("returnPlayerActions2")){
                this.aGui.changePlayerMenuState();
                this.aGui.changeListState();
                
            }
            
            else if (vCommandWord.equals("charge")){
                if ( vCommand.hasSecondWord() )
                {
                    this.aGui.changeListState();
                    this.charge(vCommand.getSecondWord());
                }
                else
                    this.aGui.println( "Charge what?" );
                
            }
            
            else if ( vCommandWord.equals( "quit" ) ) {
                if ( vCommand.hasSecondWord() )
                    this.aGui.println( "Quit what?" );
                else
                    this.endGame();
            }
            
            else if (vCommandWord.equals("test")){
                this.aIsTestRunning = true;
                if (vCommand.hasSecondWord()){
                    this.test(vCommand.getSecondWord() +".txt");
                }
                else{
                    this.aGui.println("Test de Victoire lance par defaut");
                    this.test("win.txt");
                }
                this.aIsTestRunning = false;
                
            }
            
            
            else if (vCommandWord.equals("alea")){
                if (aIsTestRunning){
                    if (vCommand.hasSecondWord()){
                        if (aRoomList.containsKey(vCommand.getSecondWord()) ) {
                            this.aAleaRoom = aRoomList.get(vCommand.getSecondWord());
                        }
                        else 
                            this.aGui.println("La teleportation par defaut ne peut etre fixee qu'a une piece existante, verifiez votre saisie");
                        
                    }
                    
                    else{
                        this.aAleaRoom = null;
                        
                    }
                }
                
                else
                    this.aGui.println("\nAttention!\nCeci est une commande de test qui ne peut donc pas être utilisee par le Player\n");
            }
            
            else if (vCommandWord.equals("unlockTest")){
                if (aIsTestRunning){
                    this.unlockTest();
                }
                
                else
                    this.aGui.println("\nAttention!\nCeci est une commande de test qui ne peut donc pas être utilisee par le Player\n");
            }
            
            else if (vCommandWord.equals("roomHasItem")){
                if (aIsTestRunning){
                    if (vCommand.hasSecondWord()){
                        if (this.roomHasItem(vCommand.getSecondWord()))
                            this.aGui.println("Room "+this.aPlayer.getRoom().getTitle() +" has "+vCommand.getSecondWord()+"\n");
                        else
                            this.aGui.println("Room "+this.aPlayer.getRoom().getTitle() + " doesn't have "+vCommand.getSecondWord()+"\n");
                        
                    }
                    
                    else{
                        this.aGui.println("Room has what?\n");
                        
                    }
                }
                
                else
                    this.aGui.println("\nAttention!\nCeci est une commande de test qui ne peut donc pas être utilisee par le Player\n");
            }
            
            else if (vCommandWord.equals("playerHas")){
                if (aIsTestRunning){
                    if (vCommand.hasSecondWord()){
                        if (this.playerHas(vCommand.getSecondWord()))
                            this.aGui.println("Player "+ this.aPlayer.getName()+ " has "+vCommand.getSecondWord()+"\n");
                        else
                            this.aGui.println("Player "+ this.aPlayer.getName()+ " doesn't have "+vCommand.getSecondWord()+"\n");
                        
                    }
                    else{
                        this.aGui.println("\nPlayer has what?\n");
                        
                    }
                }
                else
                    this.aGui.println("\nAttention!\nCeci est une commande de test qui ne peut donc pas être utilisee par le Player\n");
            }
            
            else if (vCommandWord.equals("roomIs")){
                if (aIsTestRunning){
                    if (vCommand.hasSecondWord()){
                        if (this.roomIs(vCommand.getSecondWord()))
                            this.aGui.println("Player "+ this.aPlayer.getName()+ " is in room "+vCommand.getSecondWord()+"\n");
                        else
                            this.aGui.println("Player "+ this.aPlayer.getName()+ " is not in room "+vCommand.getSecondWord()+"\n");
                        
                    }
                    else{
                        this.aGui.println("\nRoom to be checked has not been specified\n");
                        
                    }
                }
                else
                    this.aGui.println("\nAttention!\nCeci est une commande de test qui ne peut donc pas être utilisee par le Player\n");
            }
        }
    
        else if (aIsFinalMoment){
            if ( vCommandWord.equals( "flee" ) ) {
                if ( vCommand.hasSecondWord() )
                    this.aGui.println( "Il n'y a qu'une chose a fuir, pas besoin de mentionner quoi que ce soit" );
                else{
                    if ( this.aGameTime_Left <20)    
                        this.loseGame();
                    else
                        this.aGui.println( "Cette commande ne peut pas etre utilisee dans votre situation actuelle" );
                }
                this.aIsFinalMoment = false;
            }
            
            else if ( vCommandWord.equals( "launch" ) ) {
                if ( vCommand.hasSecondWord() )
                    this.aGui.println( "Il n'y a qu'un seul bouton Launch, pas besoin de mentionner quoi que ce soit" );
                else{
                    if (this.aGameTime_Left <20) {   
                        this.startWinCountDown();
                        aGameTimer.stop();
                    }
                    else
                        this.aGui.println( "Cette commande ne peut pas etre utilisee dans votre situation actuelle" );
                }
                this.aIsFinalMoment = false;
            }
            else if ( vCommandWord.equals( "launchTest" ) ) {
                if (aIsTestRunning){
                    this.launchTest();
                    this.aIsFinalMoment = false;
                }
                else
                    this.aGui.println("\nAttention!\nCeci est une commande de test qui ne peut donc pas être utilisee par le Player\n"); 
            }
        }
        else {
            this.aGui.println("Erreur du programmeur : Commande non reconnue a ce stade!");
            
        }
    }
    
    
    /**
     *  Commande qui va traiter l'acces vers la prochaine pièce demandee
     *  @param pCommand la commande pour diriger le Player dans la prochaine Room
     */
    public void goRoom (final Command pCommand)
    {
        if (!pCommand.hasSecondWord())
        {
            this.aGui.println("Go ou ?");
            return;
        }
        
        String vDirection = pCommand.getSecondWord();
        Room vCurrentRoom = this.aPlayer.getRoom();
        
        if (!this.aDirectionWords.isDirection(vDirection)){
            this.aGui.println("Direction inconnue !");
            return;
        }
        else if (vCurrentRoom.getExit(vDirection) == null){
            if (vDirection.equals("mirror") && playerHas("Branche") && roomIs("Infirmerie")){
                this.aGui.println("\nFelicitations "+this.aPlayer.getName() +" ! Vous avez trouve l'EasterEgg du Jeu!");
                this.aGui.println("Brulee traverse le monde des mirroirs munie d'Items enchantes, et la branche que vous avez ramasse pres de Luffy en etait bien un (en reference au petit nom qu'il lui donne)\nCet Item ne pouvant etre utilise qu'une seule fois, il disparaitra apres! Vous ne pourrez donc plus revenir dans cette piece :(");
                this.aGui.println("\nPour recompenser cela, Un Item facilitant la reussite du jeu vous attend dans cette piece secrete ;)");
                this.aGui.println("\nEncore merci a Luffy et ses bobards sur Brulee :))");
                this.aPlayer.setInRoom(aEasterEgg);
                //this.aDial.setInRoom(aEasterEgg); // suit le joueur
                this.aPlayer.getInventory().removeItemFromList("Branche");
                this.printLocationInfo();
                this.aGui.showImage( aEasterEgg.getImageName() );  
            }
            else
                this.aGui.println("Pas de portes de ce cote !");
        }
        else {
            boolean vChecker = false;
            if (vCurrentRoom instanceof TransporterRoom){
                if (roomIs("Cuisine"))
                {
                    this.aGui.println("\nVous ne pouvez pas vous empecher de quitter la Cuisine sans piquer une bouteille de Cola :)\nVous realisez que vous vous etes endormi et desormais vous ouvrez vos yeux a un endroit completement different du Bateau.\n");
                }
                if (roomIs("Proue"))
                {
                    this.aGui.println("\nApres avoir vu Luffy, vous decidez de faire une sieste en songeant aux prochaines aventures qui vous attendent a bord\nMalheureusement cette sieste ne sera que de courte duree puisque Traflager Law vous a accidentellement teleporte dans autre une piece en voulant entrainer ses pouvoirs!\n");
                }
                if (aAleaRoom!=null) // pour test
                    vChecker = true;
            }
            
            Room vNextRoom = vCurrentRoom.getExit(vDirection);
            if (vChecker)
            {
                this.aPlayer.setInRoom(aAleaRoom);
                vNextRoom = this.aPlayer.getRoom();
            }

            if (vNextRoom.isExit(vCurrentRoom))
                this.aPlayer.getBackStack().push(vCurrentRoom);
            else 
                this.aPlayer.getBackStack().clear();
            
            this.aPlayer.setInRoom(vNextRoom);
            this.printLocationInfo();
            if ( vCurrentRoom.getImageName() != null )
                this.aGui.showImage( vNextRoom.getImageName() );
        }
        return;
    }
    
    /**
     *  Affiche des informations d'aide pour le joueur
     */
    private void printHelp()
    {
        this.aGui.print("Piece actuelle : ");
        this.aGui.println(this.aPlayer.getRoom().getTitle().toUpperCase());
        this.aGui.println(this.aPlayer.getRoom().getLongDescription());
        this.aGui.println("\nCommandes accessibles par saisie:");
        this.aGui.println(aParser.getCommandList());
    }    
    
    /**
     *  Commande de jeu pour observer une piece ainsi que ce qu'elle contient (Items et persos)
     */
    private void look()
    {
        this.aGui.print("Vous commencez a chercher ce qui se trouve ici...");
        this.aGui.println(this.aPlayer.getRoom().getItemDescription());
        this.aGui.println(this.aPlayer.getRoom().getCharacterDescription());
    }
    
    /**
     * Verificateur de la présence d'un Item dans une Room
     * @param pVerif l'Item a chercher
     * @return l'etat de reponse du verificateur
     */
    public boolean roomHasItem(final String pVerif)
    {
        boolean vCheck = false;
        Set<String> vItems = this.aPlayer.getRoom().getLoot().getItemList().keySet();
        for (String vItemName : vItems) {
            if (vItemName.equals(pVerif))
                vCheck = true;
        }
        return vCheck;
    }
    
    /**
     * Verificateur de la présence d'un Item dans une Room
     * @param pVerif l'Item a chercher
     * @return l'etat de reponse du verificateur
     */
    public boolean roomHasCharacter(final String pVerif)
    {
        boolean vCheck = false;
        Set<String> vCharacters = this.aPlayer.getRoom().getPersonnages().getCharacterList().keySet();
        for (String vPersonnage : vCharacters) {
            if (vPersonnage.equals(pVerif))
                vCheck = true;
        }
        return vCheck;
    }
    
    /**
     * Verificateur de la Room dans laquelle se situe le Player
     * @param pVerif la Room a verifier
     * @return l'etat de reponse du verificateur
     */
    public boolean roomIs(final String pVerif)
    {
        if (this.aPlayer.getRoom().getTitle().equals(pVerif))
            return true;
        else
            return false;
    }
    
    /**
     * Verificateur de la présence d'un Item dans l'inventaire d'un Player
     * @return l'etat de reponse du verificateur
     * @param pVerif l'Item a chercher
     */
    public boolean playerHas(final String pVerif)
    {
        boolean vCheck = false;
        Set<String> vItems = this.aPlayer.getInventory().getItemList().keySet();
        for (String vItemName : vItems) {
            if (vItemName.equals(pVerif))
                vCheck = true;
        }
        return vCheck;
    }
    
    /**
     * Regarder la description d'Item en particulier dans une Room
     * @param pNom le nom de l'Item a regarder
     */
    private void lookItem(final String pNom)
    {   
        if (roomHasItem(pNom)){
            this.aGui.println(this.aPlayer.getRoom().getLoot().getItemFromList(pNom).getItemString());
        }
        else{
            this.aGui.println("Cet item n'existe pas dans cette piece!");
        }
    }
    
    /**
     * Recuperer le Player pour acceder a ses attributs
     * @return le Player
     */
    public Player getPlayer()
    {
        return this.aPlayer;
    }
    
    /**
     * Discuter avec une personnage en particulier dans une Room
     * @param pNom le nom du personnage a faire parler
     */
    public void talk(final String pNom)
    {
        if (roomHasCharacter(pNom))
        {
            //if (this.aPlayer.getRoom().getPersonnages().
            if (pNom.equals("Dial"))
                aDial.setMessageCount(aQuestProgress);
            else if (pNom.equals("Nami") && !playerHas("Binocles")){
                this.aGui.println("Hey, Pssst "+this.aPlayer.getName()+"! Recupere les jumelles de vue posees derriere toi et reviens me parler, je dois m'assurer de quelque chose");
                return;
            }
            else if (pNom.equals("Nami"))
            {
                if (aHasSpokenToNami ==false)
                {    
                    aQuestProgress=0; //Premier avancement dans la quête
                    aHasSpokenToNami = true;
                }
            }
            else if (pNom.equals("Robin"))
            {
                if (aHasSpokenToRobin ==false)
                {    
                    aQuestProgress=1; //Premier avancement dans la quête
                    aHasSpokenToRobin = true;
                }
            }
            this.aGui.println (this.aPlayer.getRoom().getPersonnages().getCharacterFromList(pNom).getMessage());
        }
        else
            this.aGui.println("Aucun personnage portant le nom "+pNom+ " est present dans la piece pour parler");
    }
    
    /**
     * Recuperer un Item en particulier dans une Room
     * @param pNom le nom de l'Item a recuperer
     */
    private void take(final String pNom)
    {
        if (this.aPlayer.getRoom().getLoot().isOpenable()){
            if (roomHasItem(pNom)){
                if (!playerHas(pNom)){
                    if (this.aPlayer.getInventory().getTotalWeight() + this.aPlayer.getRoom().getLoot().getItemFromList(pNom).getPoids() <= this.aPlayer.getInventory().getAllowedMaxWeight())
                    {
                        this.aPlayer.getInventory().setItemToList(this.aPlayer.getRoom().getLoot().getItemFromList(pNom));
                        this.aPlayer.getRoom().getLoot().removeItemFromList(pNom);
                        if (pNom.equals("Cola"))
                            if (aHasGotCola ==false)
                            {    
                                aQuestProgress=3; // Dernier objectif dans la quete principale
                                aHasGotCola = true;
                            }
                        this.aGui.println(pNom + " mis dans l'inventaire\n");
                    }
                    else{
                        this.aGui.println("Trop Lourd! Votre capacite de charge est depassee");
                        this.aGui.println("Impossible de rajouter cet item a votre inventaire :( Peut etre trouverez-vous le moyen d'augmenter votre capacite?");
                    }
                }
                else
                    this.aGui.println("Action inutile "+this.aPlayer.getName()+", vous possedez deja cet item dans votre inventaire!");
            }
            else{
                this.aGui.println("Il n'a pas d'elements " + pNom+ " a prendre dans cette piece");
            }
        }
        else
            this.aGui.println("Vous ne pourrez pas bouger ce coffre ni en obtenir son contenu sans le deverouiller");
    }
    
    /**
     * Donner l'item desire a Zoro.
     */
    public void give(){
        this.drop("Haltere");
        this.aGui.println("Bien joue! Vous avez ramene ce que Zoro voulait, apres quoi il decide de vous confier le bout de papier indiquant les enigmes a resoudre");
        ItemToRead vGuide = new ItemToRead("Notice","Les solutions aux enigmes suivantes composent la combinaison a 4 chiffres du coffre: "+ getSolvingEnigmas(),0.5); // Message personalise pour trouver le code
        vGuide.makeUsable();
        this.aPlayer.getInventory().setItemToList(vGuide);
        if (aHasGivenToZoro ==false)
        {    
            aQuestProgress = 2; // Deuxieme objectif accompli
            aHasGivenToZoro = true;
        }
        this.aGui.println("\n"+this.aPlayer.getInventory().getItemFromList("Notice").getItemString());
    }
    
    /**
     * Tentative pour ouvrir le coffre.
     */
    private void unlock()
    {
        String vTest = new String(javax.swing.JOptionPane.showInputDialog( "Veuillez tentez une combinaison a 4 chiffres" )); 
        this.aGui.println("Tentative avec "+ vTest +"...");
        if (vTest.length() == 4) {
            int vBons = 0;
            int vPresqueBons = 0;
            for (int vI = 0; vI < vTest.length(); vI++) 
            {
                char vChiffre = vTest.charAt(vI);
                if (vChiffre == this.aCombination.charAt(vI)) // Bonne place
                {
                    vBons++;
                } 
                else if (this.aCombination.contains(String.valueOf(vChiffre))) // Bien contenu
                {
                    vPresqueBons++;
                }
            }
            
            if (vBons == 4) { // Combinaison gagnante ! 
                this.aGui.println("\nCoffre ouvert avec succes!");
                this.aPlayer.getRoom().getLoot().makeOpenable();
                if (this.aPlayer.getInventory().getTotalWeight() + this.aPlayer.getRoom().getLoot().getItemFromList("Cola").getPoids() <= this.aPlayer.getInventory().getAllowedMaxWeight())
                {
                    this.aPlayer.getInventory().setItemToList(this.aPlayer.getRoom().getLoot().getItemFromList("Cola"));
                    this.aPlayer.getRoom().getLoot().removeItemFromList("Cola");
                    if (aHasGotCola ==false)
                    {    
                        aQuestProgress=3; // Dernier objectif dans la quete principale
                        aHasGotCola = true;
                    }
                    this.aGui.println("Cola mis dans l'inventaire\n");
                }
                else
                {
                    this.aGui.println("Impossible de rajouter cet item a votre inventaire :(");
                }
            } 
            else
            {
                this.aGui.println("\nChiffres corrects et bien placés : " + vBons);
                this.aGui.println("Chiffres corrects mais mal placés : " + vPresqueBons);
                this.aGui.println("\nVous n'avez pas la bonne combinaison du coffre, veuillez retenter autre chose!\n");
            }
        } 
        else
        {
            this.aGui.println("Veuillez saisir une combinaison à 4 chiffres !");
        }
    }
    
    /**
     * Commande qui contourne le probleme de la generation aleatoire du code du coffre pour le fichier test.
     */
    private void unlockTest ()
    {
        this.aGui.println("Coffre ouvert avec succes!");
        this.aPlayer.getRoom().getLoot().makeOpenable();
        if (this.aPlayer.getInventory().getTotalWeight() + this.aPlayer.getRoom().getLoot().getItemFromList("Cola").getPoids() <= this.aPlayer.getInventory().getAllowedMaxWeight())
        {
            this.aPlayer.getInventory().setItemToList(this.aPlayer.getRoom().getLoot().getItemFromList("Cola"));
            this.aPlayer.getRoom().getLoot().removeItemFromList("Cola");
            this.aGui.println("Cola mis dans l'inventaire\n");
        }
        else
        {
            this.aGui.println("Impossible de rajouter cet item a votre inventaire :(");
        }
    }
    
    /**
     * Lacher un Item en particulier dans une Room
     * @param pNom le nom de l'Item a lacher
     */
    private void drop(final String pNom)
    {
        if (playerHas(pNom)){
            if (this.aPlayer.getInventory().getItemList().size() > 0)
            {
                this.aPlayer.getRoom().getLoot().setItemToList(this.aPlayer.getInventory().getItemFromList(pNom));
                this.aPlayer.getInventory().removeItemFromList(pNom);
                this.aGui.println(pNom + " depose et sorti de l'inventaire\n");
            }
            else{
                this.aGui.println("Il n'y a plus rien a deposer!");
            }
        }
        else{
            if (!pNom.equals("Haltere"))
                this.aGui.println("Cet element n'existe pas dans l'inventaire et ne peut donc pas etre depose");
        }
    }
    
    /**
     * Charge le Beamer dans la Current Room
     * @param pNom le Beamer a charger
     */
    private void charge(final String pNom)
    {
        if (playerHas(pNom)){
            Item vItem = this.aPlayer.getInventory().getItemFromList(pNom);
            if (vItem instanceof Beamer){
                Beamer vBeamer = (Beamer) vItem;
                vBeamer.setCharge(true);
                vBeamer.setBeamerRoom(this.aPlayer.getRoom());
                this.aGui.println("Le beamer a ete charge, si vous l'utilisez vous serez teleporte a "+ vBeamer.getBeamerRoom().getTitle());
            }
            else
                this.aGui.println("Cet item n'est pas un Beamer et ne peut donc pas etre charge");
        }
        else
            this.aGui.println("Charger quoi?");
    }
    
    /**
     * Utiliser un Item en particulier dans une Room
     * @param pItemName le nom de l'Item a lacher
     */
    private void use(final String pItemName)
    {
        if (playerHas(pItemName)){
            if (this.aPlayer.getInventory().getItemFromList(pItemName).isUsable())
            {
                //Disjonction de cas - Va contenir tous les differents item utilisables et leurs effets
                
                if (pItemName.equals("Cookie"))
                {
                    this.aGui.println("La charge maximale de votre inventaire est montee de 10");
                    this.aPlayer.getInventory().setAllowedMaxWeight(this.aPlayer.getInventory().getAllowedMaxWeight()+ 10);
                }
    
                else if (this.aPlayer.getInventory().getItemFromList(pItemName) instanceof Beamer)
                {
                    Beamer vBeamer = (Beamer) this.aPlayer.getInventory().getItemFromList(pItemName);
                    
                    if (vBeamer.isCharged()){
                        this.aGui.println("\nTeleportation en cours!\n");
                        this.aPlayer.setInRoom(vBeamer.getBeamerRoom());
                        vBeamer.setCharge(false);
                        this.aPlayer.getBackStack().clear();
                        this.printLocationInfo();
                        if ( this.aPlayer.getRoom().getImageName() != null )
                            this.aGui.showImage( this.aPlayer.getRoom().getImageName() );
                    }
                    else
                        this.aGui.println("Vous devez charger le Beamer dans une piece avant de l'utiliser!");
                }
                
                else if (pItemName.equals("ShortTiempoDial"))
                {
                    this.aGui.println("Et Hop, vous etes revenus 30 secondes en arriere!");
                    this.setTimeLeft(this.getTimeLeft()+30);
                    TiempoDial vEngin = (TiempoDial) this.aPlayer.getInventory().getItemFromList(pItemName); // pour qu'il l'interprete comme un obj TiempoDial
                    vEngin.reduceCountUse();
                    if (vEngin.getCountUse() == 0)
                        vEngin.makeOneTimeUsable();
                    else
                        this.aGui.println("Il ne vous reste plus que "+ vEngin.getCountUse()+" utilisations de cet Item");
                }
                
                else if (pItemName.equals("TiempoDial"))
                {
                    this.aGui.println("La technologie de Vegapunk est merveilleuse! Vous avez remonte le temps de 3 minutes");
                    this.aGui.println("Malheureusement, cet engin demande une telle puissance qu'il se detruit dans la foulee!");
                    this.setTimeLeft(this.getTimeLeft()+180);
                }
                else if (pItemName.contains("Enigme")){
                    this.aGui.println("Lecture en cours de l'Enigme...");
                    this.aGui.println(aPlayer.getInventory().getItemFromList(pItemName).getDescription());
                }
                
                if (this.aPlayer.getInventory().getItemFromList(pItemName).isOneTimeUsable())
                {
                    this.aGui.println("(Cet element nest plus utilisable,il sera donc supprime de l'inventaire)");
                    this.aPlayer.getInventory().removeItemFromList(pItemName);
                }
            }
            else if (roomIs("Salle des Engins de Propulsion")){
                if (pItemName.equals("Cola")){
                    this.aPlayer.getInventory().getItemFromList(pItemName).makeUsable();
                    this.aIsEngineSet = true;
                    this.aGui.println("Le propulseur a Cola a ete charge dans les resevoirs du propulseur! Vous pouvez vous servir du Coup de Burst!");
                    //this.aGui.changePlayerMenuState();
                    this.aGui.changeFinalMenuState();
                    if (aIsTestRunning)
                    {
                        this.launchTest();
                        aGameTimer.stop();
                    }
                    else{
                        if (this.getTimeLeft() > 21)
                            this.setTimeLeft(21);
                    }
                }
            }
            else{
                this.aGui.println("Vous ne pouvez pas utiliser vous-meme cet element");
            }
        }
        else{
            this.aGui.println("L'element que vous tentez d'utiliser ne se trouve pas dans votre inventaire");
        }
    }
    
    /**
     *  Commande de jeu pour observer une piece ainsi que ce qu'elle contient (Items et persos)
     */
    private void start()
    {
        //this.aGui.enable(true);
        aPlayer.setInRoom(aBaseRoom);
        aHasWon = false;
        aHasLost = false;
        this.aGui.getStarted();
        this.startTimerCountDown();
        if ( this.aPlayer.getRoom().getImageName() != null )
                this.aGui.showImage( this.aPlayer.getRoom().getImageName() );
        this.printLocationInfo();
    }
    
    /**
     * Lance le Minuteur du Jeu, le Player doit trouver une solution avant le temps imparti
     */
    public void startTimerCountDown() { // developpe conjointement avec un camarade
        aGameTime_Left = 900; 
        aGameTimer = new Timer(ONE_SECOND, new ActionListener() {
            public void actionPerformed(ActionEvent vEventS) {
                aGameTime_Left--; 
                if (aGameTime_Left == 300) 
                    aGui.println("\nCinq minutes restantes");
                if (aGameTime_Left == 120) 
                    aGui.println("\nPlus que deux minutes avant l'attaque ennemie, ne tardez pas trop");
                else if (aGameTime_Left == 60) 
                    aGui.println("\nUNE minute avant la catastrophe, depêchez-vous "+ aPlayer.getName() +"!");
                else if (aGameTime_Left == 30) 
                    aGui.println("\nATTENTION, il semblerait que le navire ennemi de la Marine semble preparer une redoutable attaque!");
                else if (aGameTime_Left == 20) 
                    aGui.println("\nAttendez mais");
                else if (aGameTime_Left == 19) {
                    aIsFinalMoment = true;
                    if (!aGui.isFinalMenuOpened()){ //placer sur les boutons finaux si ce n'est pas deja fait
                        aGui.UpdateBoutons();
                        aGui.changeFinalMenuState();
                    }
                    aPlayer.getBackStack().clear();
                    aGui.println("\nIl s'agit en fait... d'un BOULET DE CANON GEANT?!");
                    aGui.println("Mais qui aurait la force suffisante pour balancer ca!?");
                    aGui.println("Usopp et le reste de l'equipage est en panique!");
                    aGui.println("Qu'allez vous faire? Decidez d'une action ET VITE\n");
                    aGui.showImage("threat.png");
                }
                else if (aGameTime_Left == 5) {
                    aGui.println("\nL'attaque est Imminente");
                    aGui.println(aPlayer.getName() + ", lancez le Coup de Burst !");
                    //aGui.enable(false);
                }
                
                else if (aGameTime_Left <= 0) {
                    if (!aHasWon){
                        loseGame();
                        aGui.stopTimer();
                    }
                    else{
                        aGui.stopTimerWon();
                    }
                    aGameTimer.stop();
                } else {
                    aGui.updateTimer(aGameTime_Left); 
                }
            }
        });
        aGameTimer.start(); 
    }
    
    /**
     * Generateur de l'ensemble des enigmes a resoudre pour trouver le code
     * @return l'ensemble des enigmes necessaires pour gagner
     */
    public String getSolvingEnigmas() {
        StringBuilder vSolution = new StringBuilder();
        String vRandomizedCode = randomizedString(aCombination);
        char[] vCodeSliced = vRandomizedCode.toCharArray(); // Conversion des chiffres du code en valeur numerique (auparavant String) placees dans une array
        
        for (char vChiffre : vCodeSliced){
            String vKey = String.valueOf(vChiffre); // Conversion en String
            String vEnigme = aEnigmeList.get(vKey);
            if (!vSolution.toString().contains(vEnigme))
            {
                vSolution.append(vEnigme);
                vSolution.append(" ");
            }
        }
        return vSolution.toString(); // remise en forme String
    }
    
    
    /**
     * Permet de shuffle le code a trouver afin de renvoyer les Enigmes dans un ordre aleatoire
     * @param pCode le code du coffre a trouve pour gagner
     * @return le code a dechiffre mais trie aleatoirement
     */
    public String randomizedString(final String pCode) {
        char[] vCodeSliced = pCode.toCharArray();
        Random vRandom = new Random();
        for (int vI = vCodeSliced.length - 1; vI > 0; vI--) {
            int vIndex = vRandom.nextInt(vI + 1); // index de ref
            // inverser les places de vCodeSliced[i] et vCodeSliced[index]
            char vTemp = vCodeSliced[vI];
            vCodeSliced[vI] = vCodeSliced[vIndex];
            vCodeSliced[vIndex] = vTemp;
        }
        return new String(vCodeSliced); // renvoie sous forme de String
    }
    
    
    /**
     *  Accesseur au decompte du jeu
     *  @return le temps restant a jouer
     */
    public int getTimeLeft(){
        return this.aGameTime_Left;
    }
    
    /**
     *  Modifie le temps restant
     *  @param pTime la nouvelle limite de temps
     */
    public void setTimeLeft(final int pTime){
         this.aGameTime_Left = pTime;
    }
    
    /**
     * Permet d'acceder a la derniere Room indiquee dans l'historique du Player
     */
    private void back()
    {
        if (this.aPlayer.getBackStack().isEmpty()){
            this.aGui.println("Vous n'avez pas la possibilite de revenir en arriere a partir d'ici");
        }
        else {
            this.aPlayer.setInRoom(this.aPlayer.getBackStack().pop());
            this.printLocationInfo();
            if ( this.aPlayer.getRoom().getImageName() != null )
                this.aGui.showImage( this.aPlayer.getRoom().getImageName() );
        }
        
    }
    
    /**
     * Affiche le contenu de l'inventaire du joueur
     */
    private void inventory()
    {
        this.aGui.println(this.aPlayer.getInventoryDescription());
    }
    
    /**
     *  Affiche des infos sur la localisation du joueur
     */
    private void printLocationInfo()
    {
        this.aGui.print("Vous etes ");
        this.aGui.println(this.aPlayer.getRoom().getDescription());
        this.aGui.println(this.aPlayer.getRoom().getExitString());
        this.aGui.print(" ");
    }
    
    /**
     * Lancement de test d'automatisation de commandes sur le jeu
     * @param pNomFichier le Nom du fichier a tester
     */
    public void test( final String pNomFichier )
    {
        Scanner vSc;
        try { // pour "essayer" les instructions suivantes :
            vSc = new Scanner( new File( pNomFichier ) );
            while ( vSc.hasNextLine() ) {
                String vLigne = vSc.nextLine();
                if (!vLigne.contains("//")) 
                    interpretCommand(vLigne);
                // traitement de la ligne lue si ce n'est pas un commentaire
            } // while
        } // try
        catch ( final FileNotFoundException pFNFE ) {
            // traitement en cas d'exception
        } // catch
    } // test
    
    /**
     *  Commande pour gagner le jeu.
     */
    private void launchTest()
    {
        
        this.aGui.println( "\nQUE TOUT LE MONDE S'AGGRIPE A QUELQUE CHOSE!\n" );
        this.aGui.println( "\nCoup...De...BUUUURST" );
        this.aGui.println( "Le Thousand Sunny s'est tire de justesse de cette situation perilleuse" );
        this.aGui.println( "Grace a vos efforts, l'equipage s'est envole tres haut dans les cieux, loin de toute menace ennemie" );
        this.aGui.println( "BRAVO "+ this.aPlayer.getName()+" :)" );
        this.aGui.getStarted();
        this.aGui.changeFinalMenuState();
        this.aGui.showImage( "win.png" );
        this.aHasWon = true;
    }
    
    /**
     *  Commande pour perdre le jeu.
     */
    private void loseGame()
    {
        this.aGui.println( "\nTROP TARD" );
        this.aGui.println( "\nCe boulot de canon est juste... beaucoup trop massif" );
        this.aGui.println( "Vos efforts auront ete vains puisque l'equipage n'a aucun moyen de s'enfuir d'ici" );
        this.aGui.println( "\nL'impact est Brutal, le Sunny est completement detruit, les membres de l'equipage ont saute du bateau et tentent de suivre comme ils peuvent" );
        this.aGui.println( "Mais la Marine est deja la pour capturer ces malfrats defaits" );
        this.aGui.println( "\nVOUS AVEZ ECHOUE" );
        this.aGui.println( "Voulez-vous retenter une chance?");
        this.aGui.getStarted();
        this.aGui.changeFinalMenuState();
        this.aGui.showImage( "lose.png" );
        this.aHasLost = true;
        this.aGui.stopTimer();
        aGameTimer.stop();
    }
    
    /**
     * Permet de realiser un affichage en differe pour l'effet de suspense de la scene finale
     */
    public void startWinCountDown() { // developpe conjointement avec un camarade
        this.aGui.getStarted();
        this.aGui.changeFinalMenuState();
        aBurstTimerCountdown = 0; 
        aBurstTimer = new Timer(ONE_SECOND, new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                aBurstTimerCountdown++; 
                if (aBurstTimerCountdown == 1) 
                    aGui.println( "\nQUE TOUT LE MONDE S'AGGRIPE A QUELQUE CHOSE!" );
                else if (aBurstTimerCountdown == 3) 
                    aGui.println("Lancement imminent");
                else if (aBurstTimerCountdown == 5) 
                    aGui.println("\nCoup..");
                else if (aBurstTimerCountdown == 6) 
                    aGui.println("De...");
                else if (aBurstTimerCountdown == 7) 
                {
                    aGui.println("BUUUUUURST !!!");
                    aGui.showImage( "win.png" );
                    
                    aGui.showImage( "win.png" );
                }
                else if (aBurstTimerCountdown == 10) {
                    aGui.println( "\nLe Thousand Sunny s'est tire de justesse de cette situation perilleuse" );
                }
                else if (aBurstTimerCountdown == 12) {
                    aGui.println( "Grace a vos efforts, l'equipage s'est envole tres haut dans les cieux, loin de toute menace ennemie" );
                    aGui.println( "\nBRAVO "+ aPlayer.getName()+" :)" );
                }
                else if (aBurstTimerCountdown == 13) {
                    aBurstTimer.stop();
                    aHasWon = true;
                }
            }
        });
        aBurstTimer.start(); 
    }
    
    /**
     *  Commande pour quitter le jeu.
     */
    private void endGame()
    {
        if (this.aGui.hasStarted())
            this.aGui.getStarted();
        aIsFinalMoment = false;
        setTimeLeft(0);
        aGui.stopTimer();
        aGameTimer.stop();
        if (aHasWon){
            this.aGui.showImage( "good_end.jpeg" );
            this.aGui.println( "\nRendez-vous dans de prochaines aventures, pirate!" );
        }
        else if(aHasLost){
            this.aGui.showImage( "bad_end.jpeg" );
            this.aGui.println( "\nVous vous debrouillerez mieux la prochaine-fois :)\nUn Mugiwara n'abandonne jamais!" );
        }
        else {
            this.aGui.showImage( "end.jpg" );
            this.aGui.println("\nVous venez d'interrompre votre session de jeu! Mais c'est pas grave, vous irez plus vite dans vos missions pour la prochaine fois!");
        }
        this.aGui.println("\n\nRelancement du Jeu");
        this.aGui.println( "\nVous etes sur le menu d'accueil, cliquez ou tapez start si vous souhaitez relancer le jeu" );
        //this.aGui.enable( true );
    }
    
}
