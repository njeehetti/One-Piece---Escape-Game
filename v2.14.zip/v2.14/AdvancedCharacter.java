import java.util.HashMap;
import java.util.Set;
/**
 * Classe MovingCharacter - un lieu du jeu d'aventure Zuul.
 *
 * @author Njee Hettiarachchi
 */
public class AdvancedCharacter extends Character
{
    /**
     * Room du perso
     */
    private Room aCurrentRoom = null;
    
    /**
     * HashMap du texte des perso. Permettra d'accorder plusieurs lignes de dialogue
     */
    private HashMap<Integer, String> aMessagesList;
    
    /**
     * Pour indiquer un message a indice precis dans la HashMap de Texte.
     */
    private int aMessageCounter;
    
    
    /**
     * Constructeur par defaut de la classe AdvancedCharacter
     * Initialise un nouvel objet AdvancedCharacter avec un titre, une description et un message.
     * @param pName Le nom du AdvancedCharacter.
     * @param pDescription La description du AdvancedCharacter
     */
    public AdvancedCharacter(final String pName,final String pDescription)
    {
        super(pName,pDescription);
        this.aMessagesList = new HashMap<>();
        aMessageCounter = 0;
    }

    /**
     * Accesseur
     * @return l'indice de message
     */
    public int getMessageCount(){
        return this.aMessageCounter;
    }
    
    /**
     * Modifie l'indice de message
     * @param pVal la nouvelle valeur d'indice
     */
    public void setMessageCount(final int pVal){
        this.aMessageCounter = pVal;
    }
    
    /**
     * Accesseur de la Room ou se trouve le joueur
     * @return la Room ou se trouve le joueur
     */
    public Room getRoom()
    {
        return this.aCurrentRoom;
    }
    
    /**
     * Modificateur de la Room ou se trouve le Character 
     * @param pRoom la Room ou placer le Personnage au debut du jeu
     */
    public void setRoom(final Room pRoom)
    {
         this.aCurrentRoom = pRoom;
    }
    
    /**
     * Definit la piece actuelle ou se trouve le perso.
     * @param pRoom La piece à définir comme piece actuelle du perso.
     */
    public void setInRoom(final Room pRoom)
    {
        aCurrentRoom.getPersonnages().removeCharacterFromList(this);
        this.setRoom(pRoom);
        pRoom.getPersonnages().setCharacterToList(this);
    }
    
    /**
     * Accesseur du message du character. Ici le personnage a differentes lignes de dialogue, stockees dans une HashMap dediee
     * @return le message specifique de dialogue.
     */
    @Override
    public String getMessage()
    {
        return aMessagesList.get(aMessageCounter);
    }
    
    /**
     * Ajouter des lignes de dialogue dans une HashMap dediee, pour faire parler le Character de differentes manieres
     * @param pIndex la position dans la HashMap ou inserer le texte
     * @param pString le dialogue a ajouter au Character
     */
    public void setMessage(final int pIndex, final String pString)
    {
        this.aMessagesList.put(pIndex,pString);
    }
}

