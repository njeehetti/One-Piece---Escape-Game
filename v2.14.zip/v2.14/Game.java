 
/**
 * Classe Game - le moteur du jeu d'aventure Treasure Cruise.
 *
 * @author Njee
 */
public class Game
{
    /**
     * Interface utilisateur associée pour l'affichage et l'interaction.
     */
    private UserInterface aGui;
    
    /**
     * Moteur de jeu associé pour la logique et le contrôle du jeu.
     */
    private GameEngine aEngine;
        
    /**
     * Créez le jeu et initialisez sa carte interne. Créez l'interface et liez-la au jeu.
     */
    public Game() 
    {
        this.aEngine = new GameEngine();
        this.aGui = new UserInterface( this.aEngine );
        this.aEngine.setGUI( this.aGui );
    }
} // Game
