
/**
 * This class is part of the "World of Zuul" application. 
 * "World of Zuul" is a very simple, text based adventure game.  
 * 
 * This class holds an enumeration table of all command words known to the game.
 * It is used to recognise commands as they are typed in.
 *
 * @author  Michael Kolling and David J. Barnes + D.Bureau
 * @version 2008.03.30 + 2019.09.25
 */

public class CommandWords
{
    /**
    * Tableau contenant les commandes valides disponibles pour une action.
    */
    private final String[] aValidCommands;
    
    /**
    * Tableau simplifie des commandes valides disponibles pour une action.
    */
    private final String[] aSimpleCommands;
    
    /**
     * Constructor - initialise the command words.
     */
    public CommandWords()
    {
        this.aValidCommands = new String[] {
        "go", "help", "quit", "look", "start", "back",
        "take", "drop", "inventory", "test", "roomHas", 
        "playerHas", "roomIs", "playerActions", "give", 
        "returnPlayerActions1", "returnPlayerActions2", 
        "use", "itemlist","charge","alea","talk","unlock","unlockTest","flee","launch","launchTest"};
        
        this.aSimpleCommands = new String[] {
        "go", "help", "quit", "look", "start", 
        "back","take", "drop", "inventory", "use", 
        "charge","talk","unlock","give","flee","launch"};
    } // CommandWords()

    /**
     * Vérifie si la String donnée en saisie est une Command valide ou pas. 
     * @param pString qui est censée être une Command à tester
     * @return true if a given string is a valid command,
     * false if it isn't.
     */
    public boolean isCommand( final String pString )
    {
        for ( int vI=0; vI<this.aValidCommands.length; vI++ ) {
            if ( this.aValidCommands[vI].equals( pString ) )
                return true;
        } // for
        // if we get here, the string was not found in the commands :
        return false;
    } // isCommand()
    
    /**
     * @return La String de tous les Commandes disponible à la saisie
     */
    public String getCommandList()
    {   
        String pList = "";
        for (String pCommand : aSimpleCommands) {
            pList += pCommand + "  ";
        }
        return pList; 
    }
} // CommandWords