import java.util.HashMap;
import java.util.Set;

/**
 * Décrivez votre classe CharacterList ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class CharacterList
{
    
    /**
     * Liste des objets, associant chaque objet à une chaine de caracteres correspondante.
     */
    private HashMap<String, Character> aCharacterList;
    
    /**
     * Constructeur d'objets de classe CharacterList
     */
    public CharacterList()
    {
        // initialisation des variables d'instance
        aCharacterList = new HashMap<String,Character>();
    }

    /**
     * Ajoute un element a la liste des objets
     * @param pCharacter L'element à ajouter à la liste.
     */
    public void setCharacterToList(final Character pCharacter)
    {
        aCharacterList.put(pCharacter.getName(),pCharacter);
    }
    
    /**
     * Supprime un element de la liste des objets
     * @param pCharacter La chaine correspondant a l'element a supprimer de la liste.
     */
    public void removeCharacterFromList(final Character pCharacter) {
        aCharacterList.remove(pCharacter.getName());
    }
    
    
    /**
     * Recupere un element de la liste des objets correspondant a la chaine donnee.
     * @param pString La chaine correspondant a l'element a recuperer de la liste.
     * @return L'objet correspondant a la chaine donnee.
     */
    public Character getCharacterFromList(final String pString)
    {
        return aCharacterList.get(pString);
    }
    
    /**
     * Renvoie la hashmap des  character
     * @return La hashmap des objets character .
     */
    public HashMap<String,Character> getCharacterList() {
        return aCharacterList;
    }
    
    /**
     * Renvoie la String des characters compris dans la piece
     * @return une string de characters.
     */
    public String getCharacterListString() {
        String vSortie = new String();
        Set<String> vKeys = this.getCharacterList().keySet();
        for (String vCharacterName : vKeys) {
            if (!(this.getCharacterFromList(vCharacterName) instanceof FollowingCharacter)) {
                vSortie += "- " + this.getCharacterFromList(vCharacterName).getCharacterString(); // Je ne veux pas afficher le Dial dans toutes les pieces ou je me rends, car je sais deja que je le porte sur moi
            }
        }
        return vSortie;
    }
}
