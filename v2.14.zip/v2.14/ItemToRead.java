import java.util.HashMap;
import java.util.Set;
/**
 * Classe ItemToRead - Sous classe de Item pour renvoyer une Item String dediee pour les Items a lire.
 *
 * @author Njee Hettiarachchi
 */
public class ItemToRead extends Item
{
    /**
     * Constructeur par defaut de la classe ItemToRead.
     * Initialise un nouvel objet ItemToRead avec un titre, une description et un poids.
     * @param pTitle Le titre de l'Item.
     * @param pDescription La description de l'Item.
     * @param pPoids Le poids de l'Item.
     */
    public ItemToRead(final String pTitle,final String pDescription, final double pPoids)
    {
        super(pTitle,pDescription,pPoids);
    }

    /**
     * Methode de texte, qui retourne le message d'un item lisible, sans mention de charge dans l'inventaire
     * @return la description associee à l'Item actuel.
     */
    @Override
    public String getItemString()
    {
        return this.getTitle() + " : " + this.getDescription() + "\n";
    } //get desc
    
    
}

