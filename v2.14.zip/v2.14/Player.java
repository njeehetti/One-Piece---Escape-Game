import java.util.HashMap;
import java.util.Stack;
import java.util.Set;

/**
 * Décrivez votre classe Player ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class Player
{
    /**
     * Nom du joueur.
     */
    private String aNom;
    
    /**
     * Piece actuelle ou se trouve le joueur.
     */
    private Room aCurrentRoom;
    
    /**
     * Inventaire du joueur contenant les Items qu'il possede.
     */
    private ItemList aInventory;
    
    /**
     * Pile representant l'historique des pieces visitees par le joueur.
     */
    private Stack<Room> aBackStack;
    
    //Ensemble de checkers pour le quest Updater 
    /**
     * Task1
     */
    private boolean aHasSpokenToRobin =false;

    /**
     * Task2
     */
    private boolean aHasGivenToZoro =false;

    /**
     * Task2
     */
    private boolean aHasGotCola =false;
    
    /**
     * Constructeur d'objets de classe Player
     * @param pPrenom le nom du joueur
     */
    public Player(final String pPrenom)
    {
        // initialisation des variables d'instance
        this.aNom = pPrenom;
        this.aInventory = new ItemList();
        this.aBackStack = new Stack<>();
        this.aInventory.setAllowedMaxWeight(10);
    }
    
    /**
     * Indique si le Player a parle avec Robin.
     *
     * @return true si c'est le cas, false sinon.
     */
    public boolean getAHasSpokenToRobin() {
        return aHasSpokenToRobin;
    }
    
    /**
     * Indique si le Player a parle avec Zoro.
     *
     * @return true si c'est le cas, false sinon.
     */
    public boolean getAHasGivenToZoro() {
        return aHasGivenToZoro;
    }
    
    /**
     * Indique si le Player a obtenu du Cola.
     *
     * @return true si c'est le cas, false sinon.
     */
    public boolean getAHasGotCola() {
        return aHasGotCola;
    }
    
    /**
     * Accesseur du nom du joueur.
     * @return Le nom du joueur.
     */
    public String getName()
    {
        return this.aNom;
    }
    
    /**
     * Accesseur de l'inventaire du joueur.
     * @return Le nom du joueur.
     */
    public ItemList getInventory()
    {
        return aInventory;
    }
    
    /**
     * Accesseur de la Room ou se trouve le joueur
     * @return la Room ou se trouve le joueur
     */
    public Room getRoom()
    {
        return this.aCurrentRoom;
    }
    
    /**
     * Definit le nom du joueur.
     * @param pNom Le nom du joueur.
     */
    public void setName(final String pNom)
    {
        this.aNom = pNom;
    }
    
    /**
     * Definit la piece actuelle ou se trouve le joueur.
     * @param pRoom La piece à définir comme piece actuelle du joueur.
     */
    public void setInRoom(final Room pRoom)
    {
        this.aCurrentRoom = pRoom;
    }
    
    /**
     * Accesseur de l'historique des pieces visitees
     * @return l'historique des pieces visitees
     */
    public Stack<Room> getBackStack() {
        return aBackStack;
    }
    
    /**
     * Renvoie la liste des items de l'inventaire du joueur
     * @return la liste des items de l'inventaire du joueur
     */
    public String getInventoryDescription()
    {
        String vSortie = new String();
        if (this.aInventory.getItemList().isEmpty()){
            vSortie += "\nVous n'avez aucun item dans votre inventaire\n";
        }
        else{
            vSortie += "\nItems presents dans l'inventaire du joueur "+ this.getName() +":\n\n";
            vSortie += aInventory.getInventoryList();
            vSortie += "\nCharge totale : " + aInventory.getTotalWeight() + "\n";
        }
        return vSortie;
    } //get desc
}
