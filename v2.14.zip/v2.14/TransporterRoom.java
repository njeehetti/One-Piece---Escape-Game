import java.util.ArrayList;
import java.util.Random;
import java.util.HashMap;
import java.util.Set;

/**
 * Décrivez votre classe TransporterRoom ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */

public class TransporterRoom extends Room 
{
    /**
     * Constructeur naturel de la sous-classe Room.
     * Initialise une nouvelle instance de Room avec un titre et une description grace au constructeur de Room (via super)
     * @param pTitle le titre de la Room
     * @param pDescription la description de la Room
     */
    public TransporterRoom(final String pTitle,final String pDescription) {
        super(pTitle, pDescription);
    }
    
    
    
    /**
     * /
     * Recherche d'une piece aleatoire dans la listes des pieces de jeu
     * @param pDirection la String de direction pour la prochaine Room
     * @return la prochaine piece dans laquelle le Player va se trouver
     */
    @Override
    public Room getExit(final String pDirection) {
        Set<String> vRoomNames = GameEngine.getRoomList().keySet(); // recuperation de tous les noms en String des pieces du jeu
        ArrayList<String> vRoomList = new ArrayList<>(vRoomNames); // creation d'une liste avec tous ces noms
        Random vRandom = new Random();
        int randomIndex = vRandom.nextInt(vRoomList.size()); // l'indice aleatoire qui permettra de faire 
        String vRandomExit = vRoomList.get(randomIndex); // un nom de piece a ete choisi aleatoirement
        return GameEngine.getRoomList().get( vRandomExit ); // une piece de joue sera renvoyee aleatoirement pour la prochaine piece de jeu
    }
}

    

