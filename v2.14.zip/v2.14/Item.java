import java.util.HashMap;
import java.util.Set;
/**
 * Classe Item - un lieu du jeu d'aventure Zuul.
 *
 * @author Njee Hettiarachchi
 */
public class Item
{
    /**
     * Titre de l'Item.
     */
    private String aTitle;
    
    /**
     * Description de l'Item.
     */
    private String aDescription;
    
    /**
     * Poids de l'Item.
     */
    private double aWeight;
    
    
    /**
     * Vérification si l'objet est utilisable
     */
    private boolean aIsUsable;
    
    /**
     * Vérification si l'objet est utilisable une seule fois
     */
    private boolean aIsOneTimeUsable;
    
    /**
     * Constructeur par defaut de la classe Item.
     * Initialise un nouvel objet Item avec un titre, une description et un poids.
     * @param pTitle Le titre de l'Item.
     * @param pDescription La description de l'Item.
     * @param pPoids Le poids de l'Item.
     */
    public Item(final String pTitle,final String pDescription, final double pPoids)
    {
        this.aDescription = pDescription;
        this.aTitle = pTitle;
        this.aWeight = pPoids;
        this.aIsUsable = false;
        this.aIsOneTimeUsable = false;
    }

    /**
     * Accesseur du nom de l'Item
     * @return l'attribut du nom de l'Item
     */
    public String getTitle()
    {
        return this.aTitle;
    } 

    /**
     * Accesseur de la description de l'item
     * @return l'attribut de description de la Item
     */
    public String getDescription()
    {
        return this.aDescription;
    } 
    
    /**
     * Renvoie le poids de l'Item.
     * @return Le poids de l'Item.
     */
    public double getPoids()
    {
        return this.aWeight;
    } 
    
    /**
     * Renvoie sur l'Item est utilisable.
     * @return true si c'est le cas, non le cas echant.
     */
    public boolean isUsable()
    {
        return this.aIsUsable;
    }
    
    /**
     * Rend l'Item utilisable.
     */
    public void makeUsable()
    {
        this.aIsUsable = true;
    }
    
    /**
     * Rend l'Item non utilisable.
     */
    public void makeNonUsable()
    {
        this.aIsUsable = false;
    }
    
    /**
     * Renvoie sur l'Item est utilisable une seule fois.
     * @return true si c'est le cas, non le cas echant.
     */
    public boolean isOneTimeUsable()
    {
        return this.aIsOneTimeUsable;
    }
    
    /**
     * Rend l'Item utilisable une seule fois.
     */
    public void makeOneTimeUsable()
    {
        this.aIsUsable = true;
        this.aIsOneTimeUsable = true;
    }
    
    /**
     * Methode de texte, qui retourn la description de l'Item
     * @return la description associee à l'Item actuelle.
     */
    public String getItemString()
    {
        return this.aTitle + " : " + this.aDescription + ", indice de charge de " + this.aWeight +"\n";
    } //get desc
    
    
}

